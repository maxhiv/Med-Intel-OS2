export const SIGNAL_TYPES = [
  'depreciation_flag', 'con_filed', 'con_approved', 'grant_awarded',
  'bond_issuance', 'construction_permit', 'leadership_change',
  'service_line_expansion', 'job_posting', 'news_expansion',
  'eol_equipment', 'accreditation_renewal', 'compliance_citation',
  'nih_grant', 'clinical_trial', 'fiscal_year_end',
];

export const FACILITY_TYPES = ['hospital', 'asc', 'imaging_center', 'health_system', 'medical_facility'];

export const PLAN_LIMITS = {
  starter:    { batch_daily: 10, sub_accounts: 2, reports: 3 },
  growth:     { batch_daily: 25, sub_accounts: 10, reports: 8 },
  enterprise: { batch_daily: 100, sub_accounts: 50, reports: -1 },
  internal:   { batch_daily: -1, sub_accounts: -1, reports: -1 },
};

export const CRM_TYPES = ['ghl', 'hubspot', 'salesforce', 'pipedrive', 'zoho', 'close', 'dynamics', 'other'];

export const FREE_ENRICHMENT_SOURCES = [
  'npi_registry', 'doximity', 'website_scrape', 'cms_billing',
  'professional_directory', 'clinicaltrials', 'nih_reporter',
  'propublica_990', 'hcris', 'con_filing', 'radiation_registry',
];

export const PAID_ENRICHMENT_SOURCES = [
  'apollo', 'netrows', 'zerobounce', 'bouncer', 'twilio',
  'people_data_labs', 'zoominfo', 'definitive_hc', 'openpermit',
];
