# MedIntel OS

> Multi-Tenant Medical Equipment Sales Intelligence Platform  
> Built by Hansen Holdings / SaaS Lab — Fairhope, Alabama

---

## Platform Architecture

```
L0  Hansen Holdings (platform admin — you)
 └─ L1  Accounts (e.g. Chicago Medical Exchange)
     └─ L2  Sub-accounts (reps / territories)
         └─ L3  Campaigns (signal-cohort targeted outreach)
```

**Core Principle:** The Central Intelligence DB is the platform moat. Every hospital, its equipment depreciation, purchase signals, financial health, accreditations, and verified contacts are owned by the platform — shared across all tenants.

---

## Stack

| Layer | Technology |
|-------|-----------|
| Backend API | Node.js 20 / Express 4 |
| Database | PostgreSQL 15 + pgvector (1536-dim embeddings) |
| Frontend | React 18 + Vite + Zustand + TanStack Query |
| AI | Claude Sonnet via Anthropic API |
| Scheduler | node-cron (batch sync, signal scoring, ingestion) |
| CRM layer | GHL (direct) + HubSpot (direct) + Apideck unified (200+ others) |

---

## Enrichment Policy

**Free sources run automatically.** No configuration required:
- NPI/NPPES Registry
- Doximity (physician verification)
- Facility website scrape
- CMS Medicare billing cross-reference
- Professional directories (ACHE, RSNA)
- ClinicalTrials.gov
- NIH Reporter grants
- ProPublica 990 financials

**Paid sources require your explicit approval.** Two-gate system:
1. Set `*_API_KEY` + `*_ENABLED=true` in `.env`
2. Approve the source at `/admin/enrichment` in the UI

Until BOTH gates pass, the source is never called — regardless of what's in the queue.

---

## Quick Start

```bash
bash scripts/setup.sh
# Fill in .env
npm run migrate
npm run seed
npm run dev
```

Access:
- Frontend: http://localhost:5173
- API: http://localhost:3001
- Health: http://localhost:3001/health

---

## Database Migrations

| File | Contents |
|------|---------|
| 001_extensions.sql | PostgreSQL extensions + custom ENUMs |
| 002_central_intelligence.sql | 21 central intelligence tables (no tenant scope) |
| 003_tenant_layer.sql | Accounts, users, sub-accounts, campaigns + RLS policies |
| 004_sequences_outreach.sql | Sequences, steps, enrollments, outreach drafts |
| 005_batch_sync.sql | Sync batches, items, CRM contact map, reply events |
| 006_reports.sql | Report templates, runs, outputs, schedules, shares |

---

## Batch Sync Rule

**No email is ever automatically sent.** The `BatchSyncProcessor`:
1. Packages N approved drafts per sub-account (configurable, default 10/day)
2. Pushes contact records to client's CRM
3. Saves email as **pending draft** on contact timeline
4. Logs LinkedIn draft as a note
5. The rep sees it next morning and clicks Send in GHL/HubSpot/etc.

`outreach_drafts.status = 'sent'` means **pushed to CRM**, never **emailed**.

---

## Contacts: Key Architecture

- `facility_contacts` is global (no account_id) — shared contact intelligence
- `campaign_contacts` links tenant campaigns to contacts — has account_id + RLS
- `outreach_drafts` has account_id + RLS — tenant-scoped drafts

This means two clients can both enrich the same CMO at Mayo Clinic without duplicating effort, while their drafts and campaigns stay completely isolated.

---

## Intelligence Tiers (10 layers)

1. GPO & Procurement Architecture
2. Clinical Volume & Procedure Data (CMS Medicare — free)
3. Technology & IT Stack (EHR, PACS, RIS, HIMSS EMRAM)
4. Quality, Accreditation & Certification (ACR renewal = buying trigger)
5. Workforce & Hiring Signals (job postings = equipment signals)
6. Research, Grants & Clinical Trials (NIH Reporter + ClinicalTrials.gov — free)
7. Construction, Expansion & Capital Projects
8. Competitive & Installed Base Intelligence
9. Regulatory, Compliance & Citations
10. Community, Market Position & Special Designations (CHNA)

---

*MedIntel OS v1.0.0 · Hansen Holdings · SaaS Lab · Fairhope, Alabama*
