-- MedIntel OS Migration 001: Extensions & Core Types
-- Run once per database.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- for fuzzy text search
CREATE EXTENSION IF NOT EXISTS "unaccent";

-- Custom types
CREATE TYPE ownership_type AS ENUM ('nonprofit', 'for_profit', 'government', 'unknown');
CREATE TYPE crm_type AS ENUM ('ghl', 'hubspot', 'salesforce', 'pipedrive', 'zoho', 'close', 'dynamics', 'other');
CREATE TYPE signal_type AS ENUM (
  'depreciation_flag', 'con_filed', 'con_approved', 'grant_awarded',
  'bond_issuance', 'construction_permit', 'leadership_change',
  'service_line_expansion', 'job_posting', 'news_expansion',
  'eol_equipment', 'accreditation_renewal', 'compliance_citation',
  'nih_grant', 'clinical_trial', 'fiscal_year_end'
);
CREATE TYPE contact_status AS ENUM ('unverified', 'verified', 'bounced', 'unsubscribed', 'do_not_contact');
CREATE TYPE outreach_channel AS ENUM ('email', 'linkedin', 'phone', 'both');
CREATE TYPE enrollment_status AS ENUM ('active', 'paused', 'replied', 'complete', 'unsubscribed', 'bounced');
CREATE TYPE draft_status AS ENUM ('pending', 'approved', 'sent', 'skipped', 'rejected');
CREATE TYPE sync_status AS ENUM ('pending', 'running', 'complete', 'failed', 'partial');
CREATE TYPE report_status AS ENUM ('queued', 'running', 'complete', 'failed');
CREATE TYPE plan_tier AS ENUM ('starter', 'growth', 'enterprise', 'internal');

-- Enrichment source enum (ties to EnrichmentOrchestrator)
CREATE TYPE enrichment_source AS ENUM (
  -- FREE SOURCES (no approval required)
  'npi_registry', 'doximity', 'website_scrape', 'cms_billing',
  'professional_directory', 'clinicaltrials', 'nih_reporter',
  'propublica_990', 'hcris', 'con_filing', 'radiation_registry',
  -- PAID SOURCES (require platform admin approval)
  'apollo', 'netrows', 'zerobounce', 'bouncer', 'twilio',
  'people_data_labs', 'zoominfo', 'definitive_hc', 'openpermit'
);

COMMENT ON TYPE enrichment_source IS
  'Identifies which enrichment source produced a data point. Paid sources require explicit platform admin approval before activation.';
