-- MedIntel OS Migration 005: Batch Sync Pipeline
-- Controlled daily push to client CRM. NEVER auto-sends email.

CREATE TABLE sync_batches (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  sub_account_id  UUID NOT NULL REFERENCES sub_accounts(id),
  campaign_id     UUID REFERENCES campaigns(id),
  
  crm_type        crm_type NOT NULL,
  batch_date      DATE NOT NULL,
  
  target_count    INTEGER DEFAULT 0,
  pushed_count    INTEGER DEFAULT 0,
  failed_count    INTEGER DEFAULT 0,
  
  status          sync_status DEFAULT 'pending',
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  error_log       JSONB DEFAULT '[]',
  
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_batches_account ON sync_batches(account_id, batch_date DESC);
CREATE INDEX idx_batches_status ON sync_batches(status);
ALTER TABLE sync_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY batches_isolation ON sync_batches
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

CREATE TABLE sync_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  batch_id        UUID NOT NULL REFERENCES sync_batches(id) ON DELETE CASCADE,
  account_id      UUID NOT NULL REFERENCES accounts(id),
  
  entity_type     TEXT CHECK (entity_type IN ('contact', 'company', 'deal', 'draft', 'note', 'attachment')),
  local_id        UUID NOT NULL,
  
  -- CRM response
  crm_id          TEXT,
  crm_type        crm_type,
  crm_response    JSONB,
  
  status          TEXT CHECK (status IN ('pending', 'pushed', 'failed', 'skipped')) DEFAULT 'pending',
  error_message   TEXT,
  pushed_at       TIMESTAMPTZ,
  retry_count     SMALLINT DEFAULT 0
);

CREATE INDEX idx_sync_items_batch ON sync_items(batch_id, status);

-- CRM contact mapping (dedup on re-push)
CREATE TABLE crm_contacts_map (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id),
  local_contact_id UUID NOT NULL REFERENCES facility_contacts(id),
  crm_type        crm_type NOT NULL,
  crm_contact_id  TEXT NOT NULL,
  crm_company_id  TEXT,
  crm_deal_id     TEXT,
  last_synced_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(account_id, local_contact_id, crm_type)
);

CREATE INDEX idx_crm_map_account ON crm_contacts_map(account_id, crm_type);

-- Reply / engagement events from CRM webhooks
CREATE TABLE reply_events (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id),
  draft_id        UUID REFERENCES outreach_drafts(id),
  crm_type        crm_type,
  crm_contact_id  TEXT,
  event_type      TEXT CHECK (event_type IN ('sent', 'opened', 'clicked', 'replied', 'bounced', 'unsubscribed', 'deal_stage_change')),
  raw_payload     JSONB,
  ai_classification TEXT,                      -- 'interested', 'not_now', 'unsubscribe', 'wrong_person'
  received_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_reply_events_account ON reply_events(account_id, received_at DESC);
CREATE INDEX idx_reply_events_draft ON reply_events(draft_id);
ALTER TABLE reply_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY reply_events_isolation ON reply_events
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

