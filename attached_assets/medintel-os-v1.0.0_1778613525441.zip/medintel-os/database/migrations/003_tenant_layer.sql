-- MedIntel OS Migration 003: Multi-Tenant Layer
-- All tables here carry account_id for RLS enforcement.

-- ──────────────────────────────────────────────
-- ACCOUNTS (L1 — clients like Chicago Medical Exchange)
-- ──────────────────────────────────────────────
CREATE TABLE accounts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  slug            TEXT UNIQUE NOT NULL,
  plan_tier       plan_tier DEFAULT 'starter',
  
  -- CRM config
  default_crm     crm_type DEFAULT 'ghl',
  
  -- Batch settings
  batch_limit_daily INTEGER DEFAULT 10,        -- platform enforces ceiling per plan
  
  -- Status
  status          TEXT CHECK (status IN ('active', 'suspended', 'cancelled', 'trial')) DEFAULT 'trial',
  trial_ends_at   TIMESTAMPTZ,
  
  -- Billing
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  
  -- Settings JSONB (flexible config)
  settings        JSONB DEFAULT '{}',
  
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────
-- USERS (platform admin + account users)
-- ──────────────────────────────────────────────
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID REFERENCES accounts(id),  -- NULL = platform admin (L0)
  email           TEXT UNIQUE NOT NULL,
  password_hash   TEXT NOT NULL,
  first_name      TEXT,
  last_name       TEXT,
  role            TEXT CHECK (role IN ('platform_admin', 'account_admin', 'sub_account_user', 'viewer')) NOT NULL,
  is_active       BOOLEAN DEFAULT TRUE,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_account ON users(account_id);
CREATE INDEX idx_users_email ON users(email);

-- ──────────────────────────────────────────────
-- ENRICHMENT SOURCE APPROVALS
-- Platform admin must approve each paid source before it can run.
-- This is the enforcement mechanism for "approval required" policy.
-- ──────────────────────────────────────────────
CREATE TABLE enrichment_source_approvals (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source          enrichment_source NOT NULL UNIQUE,
  approved        BOOLEAN DEFAULT FALSE,
  approved_by     UUID REFERENCES users(id),
  approved_at     TIMESTAMPTZ,
  notes           TEXT,
  monthly_budget_limit BIGINT,                 -- optional spend ceiling in cents
  current_month_spend  BIGINT DEFAULT 0,
  last_reset_at   TIMESTAMPTZ DEFAULT DATE_TRUNC('month', NOW()),
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Seed all paid sources as unapproved
INSERT INTO enrichment_source_approvals (source, approved) VALUES
  ('apollo', false),
  ('netrows', false),
  ('zerobounce', false),
  ('bouncer', false),
  ('twilio', false),
  ('people_data_labs', false),
  ('zoominfo', false),
  ('definitive_hc', false),
  ('openpermit', false);

-- ──────────────────────────────────────────────
-- SUB-ACCOUNTS (L2 — reps/regions/verticals)
-- ──────────────────────────────────────────────
CREATE TABLE sub_accounts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  
  -- CRM integration for this sub-account
  crm_type        crm_type,
  crm_credentials JSONB DEFAULT '{}',          -- encrypted at app layer before storing
  crm_sub_id      TEXT,                        -- their pipeline/user ID in the CRM
  
  -- Batch config
  batch_size_daily INTEGER DEFAULT 10,
  batch_warmup_mode BOOLEAN DEFAULT TRUE,
  
  -- Rep info
  rep_user_id     UUID REFERENCES users(id),
  rep_name        TEXT,
  rep_email       TEXT,
  timezone        TEXT DEFAULT 'America/Chicago',
  
  -- Status
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sub_accounts_account ON sub_accounts(account_id);

-- ──────────────────────────────────────────────
-- ACCOUNT FACILITIES (which facilities each account is targeting)
-- ──────────────────────────────────────────────
CREATE TABLE account_facilities (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  sub_account_id  UUID REFERENCES sub_accounts(id),
  
  status          TEXT CHECK (status IN ('identified', 'researched', 'outreach_active', 'engaged', 'qualified', 'won', 'lost', 'nurture')) DEFAULT 'identified',
  priority        SMALLINT DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  deal_score      SMALLINT DEFAULT 0 CHECK (deal_score BETWEEN 0 AND 100),
  
  notes           TEXT,
  tags            TEXT[] DEFAULT '{}',
  
  -- CRM mapping
  crm_company_id  TEXT,
  crm_deal_id     TEXT,
  
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(account_id, facility_id)
);

CREATE INDEX idx_acct_facilities_account ON account_facilities(account_id, status);
CREATE INDEX idx_acct_facilities_sub ON account_facilities(sub_account_id);

-- Enable RLS
ALTER TABLE account_facilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY account_facilities_isolation ON account_facilities
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

-- ──────────────────────────────────────────────
-- CAMPAIGNS (L3)
-- ──────────────────────────────────────────────
CREATE TABLE campaigns (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  sub_account_id  UUID NOT NULL REFERENCES sub_accounts(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  description     TEXT,
  
  -- Facility filter criteria (stored as JSONB for flexibility)
  filter_criteria JSONB DEFAULT '{}',          -- state[], facility_type[], signal_score_min, etc.
  signal_cohort   signal_type[],               -- which signals to target
  
  -- Batch settings
  batch_size_daily INTEGER DEFAULT 10,
  
  -- Status
  status          TEXT CHECK (status IN ('draft', 'active', 'paused', 'complete', 'archived')) DEFAULT 'draft',
  start_date      DATE,
  end_date        DATE,
  
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_campaigns_account ON campaigns(account_id, status);
CREATE INDEX idx_campaigns_sub ON campaigns(sub_account_id);

ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
CREATE POLICY campaigns_isolation ON campaigns
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

-- ──────────────────────────────────────────────
-- CAMPAIGN CONTACTS (links campaigns to facility_contacts)
-- ──────────────────────────────────────────────
CREATE TABLE campaign_contacts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  campaign_id     UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  account_id      UUID NOT NULL REFERENCES accounts(id),    -- denormalized for RLS
  contact_id      UUID NOT NULL REFERENCES facility_contacts(id),
  
  score           SMALLINT DEFAULT 0,
  sequence_id     UUID,                        -- FK → sequences (set on enrollment)
  
  status          TEXT CHECK (status IN ('queued', 'enrolled', 'active', 'replied', 'complete', 'paused', 'removed')) DEFAULT 'queued',
  enrolled_at     TIMESTAMPTZ,
  
  -- CRM map
  crm_contact_id  TEXT,
  crm_synced_at   TIMESTAMPTZ,
  
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(campaign_id, contact_id)
);

CREATE INDEX idx_cc_campaign ON campaign_contacts(campaign_id, status);
CREATE INDEX idx_cc_account ON campaign_contacts(account_id);

ALTER TABLE campaign_contacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY campaign_contacts_isolation ON campaign_contacts
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

