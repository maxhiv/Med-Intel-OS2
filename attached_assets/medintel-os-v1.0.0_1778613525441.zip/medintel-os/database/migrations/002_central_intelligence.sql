-- MedIntel OS Migration 002: Central Intelligence Database
-- Shared across all tenants. Platform-owned moat.
-- These tables have NO account_id — they are global.

-- ──────────────────────────────────────────────
-- CORE FACILITY REGISTRY
-- ──────────────────────────────────────────────
CREATE TABLE facilities (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  npi             VARCHAR(10) UNIQUE NOT NULL,
  name            TEXT NOT NULL,
  doing_business_as TEXT,
  facility_type   TEXT NOT NULL,               -- 'hospital', 'asc', 'imaging_center', 'health_system', etc.
  cms_id          TEXT,
  beds            INTEGER,
  ownership       ownership_type DEFAULT 'unknown',
  system_name     TEXT,                        -- parent health system name
  idn_id          UUID,                        -- FK → health_systems (future)
  
  -- Location
  address1        TEXT,
  city            TEXT,
  state           CHAR(2),
  zip             VARCHAR(10),
  county          TEXT,
  lat             NUMERIC(9,6),
  lng             NUMERIC(9,6),
  
  -- Web presence
  website         TEXT,
  
  -- Special designations (from CMS POS)
  cah_designation BOOLEAN DEFAULT FALSE,       -- Critical Access Hospital
  dsh_pct         NUMERIC(5,2),                -- Disproportionate Share %
  scp_designation BOOLEAN DEFAULT FALSE,       -- Sole Community Provider
  fqhc_designation BOOLEAN DEFAULT FALSE,      -- Federally Qualified Health Center
  teaching_hospital BOOLEAN DEFAULT FALSE,
  gme_slots       INTEGER,
  
  -- Signal composite score (recomputed nightly)
  signal_score    SMALLINT DEFAULT 0 CHECK (signal_score BETWEEN 0 AND 100),
  
  -- Tracking
  last_scraped_at TIMESTAMPTZ,
  last_enriched_at TIMESTAMPTZ,
  scrape_errors   INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_facilities_npi ON facilities(npi);
CREATE INDEX idx_facilities_state ON facilities(state);
CREATE INDEX idx_facilities_type ON facilities(facility_type);
CREATE INDEX idx_facilities_signal_score ON facilities(signal_score DESC);
CREATE INDEX idx_facilities_name_trgm ON facilities USING gin(name gin_trgm_ops);

-- ──────────────────────────────────────────────
-- FINANCIAL DOCUMENTS (append-only raw + parsed)
-- ──────────────────────────────────────────────
CREATE TABLE financial_documents (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  doc_type        TEXT NOT NULL CHECK (doc_type IN ('990','hcris','con','sec_8k','sec_10k','annual_report','bond_statement')),
  fiscal_year     SMALLINT NOT NULL,
  source_url      TEXT,
  raw_text        TEXT,
  parsed_json     JSONB,
  
  -- Key financials extracted
  total_revenue        BIGINT,
  operating_income     BIGINT,
  operating_margin_pct NUMERIC(6,2),
  capital_expenditures BIGINT,
  long_term_debt       BIGINT,
  days_cash_on_hand    NUMERIC(8,2),
  net_patient_revenue  BIGINT,
  
  ingested_at     TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(facility_id, doc_type, fiscal_year)
);

CREATE INDEX idx_fin_docs_facility ON financial_documents(facility_id, fiscal_year DESC);

-- ──────────────────────────────────────────────
-- EQUIPMENT RECORDS (from HCRIS Form S-7 + radiation registries)
-- ──────────────────────────────────────────────
CREATE TABLE equipment_records (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  modality            TEXT NOT NULL,   -- 'ct', 'mri', 'pet', 'xray', 'fluoroscopy', 'mammo', 'nuclear_med', 'ultrasound', 'linear_accelerator'
  manufacturer        TEXT,
  model               TEXT,
  serial_number       TEXT,
  install_year        SMALLINT,
  original_cost       BIGINT,
  book_value          BIGINT,
  accum_depreciation  BIGINT,
  pct_depreciated     NUMERIC(5,2),
  est_replacement_year SMALLINT,       -- computed: install_year + avg_life_years
  urgency_tier        TEXT CHECK (urgency_tier IN ('critical', 'watch', 'healthy', 'unknown')) DEFAULT 'unknown',
  
  -- Radiation registry fields
  registration_number TEXT,
  registration_date   DATE,
  last_inspection_date DATE,
  registration_expiry  DATE,
  
  -- Source tracking
  source_doc_id       UUID REFERENCES financial_documents(id),
  source_type         TEXT,            -- 'hcris', 'radiation_registry', 'con_filing', 'website'
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_equip_facility ON equipment_records(facility_id);
CREATE INDEX idx_equip_modality ON equipment_records(modality);
CREATE INDEX idx_equip_urgency ON equipment_records(urgency_tier);
CREATE INDEX idx_equip_pct_deprecated ON equipment_records(pct_depreciated DESC);

-- ──────────────────────────────────────────────
-- PURCHASE SIGNALS (computed from all intelligence sources)
-- ──────────────────────────────────────────────
CREATE TABLE purchase_signals (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  signal_type     signal_type NOT NULL,
  signal_value    TEXT,                        -- human-readable detail
  confidence      SMALLINT DEFAULT 50 CHECK (confidence BETWEEN 0 AND 100),
  source          TEXT NOT NULL,               -- source table/API that triggered this
  source_id       UUID,                        -- FK to source record if applicable
  detected_at     TIMESTAMPTZ DEFAULT NOW(),
  expires_at      TIMESTAMPTZ,                 -- NULL = permanent
  is_active       BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_signals_facility ON purchase_signals(facility_id, is_active);
CREATE INDEX idx_signals_type ON purchase_signals(signal_type);
CREATE INDEX idx_signals_detected ON purchase_signals(detected_at DESC);

-- ──────────────────────────────────────────────
-- CON FILINGS
-- ──────────────────────────────────────────────
CREATE TABLE con_filings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID REFERENCES facilities(id),
  state           CHAR(2) NOT NULL,
  filing_date     DATE,
  decision_date   DATE,
  equipment_type  TEXT,
  modality        TEXT,
  requested_amount BIGINT,
  approved_amount  BIGINT,
  status          TEXT CHECK (status IN ('pending', 'approved', 'denied', 'withdrawn')),
  applicant_name  TEXT,
  filing_url      TEXT,
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_con_facility ON con_filings(facility_id);
CREATE INDEX idx_con_state ON con_filings(state, filing_date DESC);
CREATE INDEX idx_con_status ON con_filings(status);

-- ──────────────────────────────────────────────
-- FACILITY CONTACTS (global, shared across tenants)
-- ──────────────────────────────────────────────
CREATE TABLE facility_contacts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  
  -- Identity
  first_name      TEXT,
  last_name       TEXT,
  full_name       TEXT GENERATED ALWAYS AS (first_name || ' ' || last_name) STORED,
  title           TEXT,
  department      TEXT,
  npi             VARCHAR(10),                 -- if clinician
  
  -- Contact details (may be null until enriched)
  email           TEXT,
  email_status    contact_status DEFAULT 'unverified',
  email_confidence SMALLINT DEFAULT 0,
  phone           TEXT,
  phone_type      TEXT,                        -- 'mobile', 'direct', 'main', 'voip'
  phone_valid     BOOLEAN,
  
  -- LinkedIn
  linkedin_url    TEXT,
  linkedin_data   JSONB,                       -- from Netrows
  linkedin_last_activity TIMESTAMPTZ,
  
  -- Validation
  confidence_score SMALLINT DEFAULT 0 CHECK (confidence_score BETWEEN 0 AND 100),
  verification_sources enrichment_source[] DEFAULT '{}',
  doximity_verified BOOLEAN DEFAULT FALSE,
  cms_billing_verified BOOLEAN DEFAULT FALSE,
  human_verified  BOOLEAN DEFAULT FALSE,
  human_verified_at TIMESTAMPTZ,
  human_verified_by UUID,                      -- FK → users
  
  -- Scoring
  buying_authority_score SMALLINT DEFAULT 0 CHECK (buying_authority_score BETWEEN 0 AND 10),
  
  -- Enrichment tracking
  last_enriched_at TIMESTAMPTZ,
  enrichment_sources enrichment_source[] DEFAULT '{}',
  
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_contacts_facility ON facility_contacts(facility_id);
CREATE INDEX idx_contacts_email ON facility_contacts(email) WHERE email IS NOT NULL;
CREATE INDEX idx_contacts_confidence ON facility_contacts(confidence_score DESC);
CREATE INDEX idx_contacts_name_trgm ON facility_contacts USING gin(full_name gin_trgm_ops);

-- ──────────────────────────────────────────────
-- FACILITY NEWS (scraped/monitored signals)
-- ──────────────────────────────────────────────
CREATE TABLE facility_news (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  headline        TEXT NOT NULL,
  summary         TEXT,
  source_url      TEXT,
  source_name     TEXT,
  published_at    TIMESTAMPTZ,
  signal_tags     signal_type[] DEFAULT '{}',
  raw_content     TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_news_facility ON facility_news(facility_id, published_at DESC);

-- ──────────────────────────────────────────────
-- EMBEDDINGS (pgvector — semantic search)
-- ──────────────────────────────────────────────
CREATE TABLE facility_embeddings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  chunk_text      TEXT NOT NULL,
  embedding       vector(1536),
  chunk_type      TEXT,                        -- 'financial', 'equipment', 'contact', 'news', 'con'
  source_id       UUID,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_embeddings_facility ON facility_embeddings(facility_id);
CREATE INDEX idx_embeddings_vector ON facility_embeddings USING hnsw (embedding vector_cosine_ops);

-- ──────────────────────────────────────────────
-- INTELLIGENCE EXPANSION TABLES (10 tiers)
-- ──────────────────────────────────────────────

CREATE TABLE facility_procurement (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id     UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  gpo_name        TEXT,
  gpo_tier        TEXT,
  idn_system      TEXT,
  vac_cadence     TEXT,
  fiscal_year_end TEXT,
  capital_threshold_board BIGINT,
  capital_threshold_cfo   BIGINT,
  last_updated    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_clinical_volume (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id             UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  cms_year                SMALLINT NOT NULL,
  annual_ct_volume        INTEGER,
  annual_mri_volume       INTEGER,
  annual_pet_volume       INTEGER,
  annual_xray_volume      INTEGER,
  annual_nuclear_med_volume INTEGER,
  case_mix_index          NUMERIC(5,2),
  trauma_level            SMALLINT CHECK (trauma_level BETWEEN 1 AND 4),
  inpatient_discharges    INTEGER,
  outpatient_visits       INTEGER,
  top_drg_service_lines   TEXT[],
  UNIQUE(facility_id, cms_year)
);

CREATE TABLE facility_tech_stack (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  ehr_vendor          TEXT,
  ehr_go_live_date    DATE,
  pacs_vendor         TEXT,
  ris_vendor          TEXT,
  himss_emram_score   SMALLINT CHECK (himss_emram_score BETWEEN 0 AND 7),
  teleradiology_partner TEXT,
  ai_diagnostic_tools TEXT[],
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_accreditation (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  jc_accredited       BOOLEAN DEFAULT FALSE,
  jc_last_survey_date DATE,
  jc_next_survey_est  DATE,
  acr_modalities      TEXT[],
  acr_last_accred_date DATE,
  acr_renewal_est     DATE,
  leapfrog_grade      CHAR(1) CHECK (leapfrog_grade IN ('A','B','C','D','F')),
  cms_star_rating     SMALLINT CHECK (cms_star_rating BETWEEN 1 AND 5),
  magnet_designation  BOOLEAN DEFAULT FALSE,
  specialty_certs     TEXT[],
  mqsa_cert_date      DATE,
  nrc_license_number  TEXT,
  nrc_license_expiry  DATE,
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_workforce (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id             UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  active_imaging_job_posts INTEGER DEFAULT 0,
  radiology_dir_open      BOOLEAN DEFAULT FALSE,
  csuite_changes          JSONB DEFAULT '[]',
  fte_total               INTEGER,
  fte_yoy_delta           NUMERIC(6,2),
  biomed_fte_count        INTEGER,
  last_job_scrape_at      TIMESTAMPTZ
);

CREATE TABLE facility_research (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  active_trials_count INTEGER DEFAULT 0,
  active_trials_imaging JSONB DEFAULT '[]',
  nih_grants_active   INTEGER DEFAULT 0,
  nih_grant_total_value BIGINT,
  hrsa_grants_active  INTEGER DEFAULT 0,
  gme_slots           INTEGER,
  pubmed_citation_count INTEGER DEFAULT 0,
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_construction (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  active_permits      JSONB DEFAULT '[]',
  bond_issuances      JSONB DEFAULT '[]',
  construction_news   JSONB DEFAULT '[]',
  oshpd_projects      JSONB DEFAULT '[]',
  expansion_service_lines TEXT[],
  project_est_completion  DATE,
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_competitive (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  installed_brands    TEXT[],
  primary_vendor      TEXT,
  service_contract_type TEXT,
  service_contract_holder TEXT,
  eol_equipment_flags JSONB DEFAULT '[]',
  last_purchase_brand TEXT,
  last_purchase_year  SMALLINT,
  last_purchase_modality TEXT,
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_compliance (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  cms_citations       JSONB DEFAULT '[]',
  state_survey_findings JSONB DEFAULT '[]',
  maude_reports_count INTEGER DEFAULT 0,
  osha_citations      JSONB DEFAULT '[]',
  payment_suspension_flag BOOLEAN DEFAULT FALSE,
  acr_dose_registry_member BOOLEAN DEFAULT FALSE,
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE facility_community (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID NOT NULL REFERENCES facilities(id) ON DELETE CASCADE UNIQUE,
  chna_priorities     TEXT[],
  service_area_pop    INTEGER,
  service_area_median_age NUMERIC(4,1),
  chronic_disease_indices JSONB DEFAULT '{}',
  last_updated        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE radiation_equipment_registry (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  facility_id         UUID REFERENCES facilities(id),
  state               CHAR(2) NOT NULL,
  equipment_type      TEXT NOT NULL,
  manufacturer        TEXT,
  model               TEXT,
  serial_number       TEXT,
  registration_number TEXT,
  registration_date   DATE,
  last_inspection_date DATE,
  registration_expiry DATE,
  source              TEXT DEFAULT 'state_radiation_control',
  raw_data            JSONB,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(state, registration_number)
);

CREATE INDEX idx_rad_reg_facility ON radiation_equipment_registry(facility_id);
CREATE INDEX idx_rad_reg_expiry ON radiation_equipment_registry(registration_expiry);

-- ──────────────────────────────────────────────
-- CONTACT VALIDATION INFRASTRUCTURE
-- ──────────────────────────────────────────────
CREATE TABLE contact_validation_log (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  contact_id      UUID NOT NULL REFERENCES facility_contacts(id) ON DELETE CASCADE,
  check_type      enrichment_source NOT NULL,
  result          TEXT NOT NULL,               -- 'valid', 'invalid', 'catch_all', 'not_found', etc.
  confidence_delta SMALLINT DEFAULT 0,
  raw_response    JSONB,
  checked_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_val_log_contact ON contact_validation_log(contact_id, checked_at DESC);

CREATE TABLE contact_enrichment_queue (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  contact_id      UUID NOT NULL REFERENCES facility_contacts(id) ON DELETE CASCADE,
  priority        SMALLINT DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  sources_tried   enrichment_source[] DEFAULT '{}',
  next_source     enrichment_source,
  trigger_reason  TEXT,                        -- 'initial', 'bounce', 'decay', 'manual'
  scheduled_at    TIMESTAMPTZ DEFAULT NOW(),
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  status          TEXT CHECK (status IN ('queued', 'running', 'complete', 'failed')) DEFAULT 'queued',
  error_message   TEXT
);

CREATE INDEX idx_enrich_queue_status ON contact_enrichment_queue(status, scheduled_at);
CREATE INDEX idx_enrich_queue_priority ON contact_enrichment_queue(priority DESC, scheduled_at);

