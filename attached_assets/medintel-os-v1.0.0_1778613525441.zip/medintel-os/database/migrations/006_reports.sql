-- MedIntel OS Migration 006: Report Engine

CREATE TABLE report_templates (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  account_id      UUID REFERENCES accounts(id),  -- NULL = system template (available to all)
  name            TEXT NOT NULL,
  description     TEXT,
  category        TEXT CHECK (category IN ('assets', 'financials', 'signals', 'intelligence', 'outreach', 'territory')),
  
  -- Configuration
  data_sources    TEXT[] NOT NULL,             -- table names used
  field_config    JSONB NOT NULL DEFAULT '[]', -- [{field, label, type, aggregate}]
  filter_config   JSONB NOT NULL DEFAULT '[]', -- [{field, operator, default_value, user_facing}]
  sort_config     JSONB DEFAULT '{}',
  viz_type        TEXT DEFAULT 'table',
  
  -- Output
  export_formats  TEXT[] DEFAULT ARRAY['pdf', 'csv', 'xlsx'],
  
  -- Scheduling
  schedulable     BOOLEAN DEFAULT TRUE,
  crm_attachable  BOOLEAN DEFAULT FALSE,
  
  is_system_template BOOLEAN DEFAULT FALSE,    -- ships pre-built
  is_active       BOOLEAN DEFAULT TRUE,
  created_by      UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- System templates can be seen by all accounts (no RLS on system ones)
CREATE INDEX idx_report_templates_account ON report_templates(account_id, category);
ALTER TABLE report_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY report_templates_isolation ON report_templates
  USING (
    is_system_template = TRUE
    OR account_id = NULLIF(current_setting('app.account_id', true), '')::UUID
  );

CREATE TABLE report_runs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  template_id     UUID NOT NULL REFERENCES report_templates(id),
  account_id      UUID NOT NULL REFERENCES accounts(id),
  triggered_by    TEXT CHECK (triggered_by IN ('manual', 'schedule', 'api')) DEFAULT 'manual',
  triggered_by_user UUID REFERENCES users(id),
  
  -- Runtime params (can override template defaults)
  runtime_filters JSONB DEFAULT '{}',
  
  status          report_status DEFAULT 'queued',
  row_count       INTEGER,
  duration_ms     INTEGER,
  error_message   TEXT,
  
  queued_at       TIMESTAMPTZ DEFAULT NOW(),
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ
);

CREATE INDEX idx_report_runs_account ON report_runs(account_id, queued_at DESC);
ALTER TABLE report_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY report_runs_isolation ON report_runs
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

CREATE TABLE report_outputs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  run_id          UUID NOT NULL REFERENCES report_runs(id) ON DELETE CASCADE,
  format          TEXT CHECK (format IN ('pdf', 'csv', 'xlsx', 'json')) NOT NULL,
  storage_path    TEXT NOT NULL,               -- local path or GCS path
  file_size_kb    INTEGER,
  download_url    TEXT,                        -- signed URL (temp)
  expires_at      TIMESTAMPTZ DEFAULT NOW() + INTERVAL '7 days',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE report_schedules (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  template_id     UUID NOT NULL REFERENCES report_templates(id),
  account_id      UUID NOT NULL REFERENCES accounts(id),
  
  cron_expr       TEXT NOT NULL,               -- e.g. '0 7 * * 1' (Mon 7am)
  timezone        TEXT DEFAULT 'America/Chicago',
  
  recipients      TEXT[] DEFAULT '{}',         -- email addresses
  crm_attach      BOOLEAN DEFAULT FALSE,
  export_format   TEXT DEFAULT 'pdf',
  
  is_active       BOOLEAN DEFAULT TRUE,
  next_run_at     TIMESTAMPTZ,
  last_run_id     UUID REFERENCES report_runs(id),
  
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_report_schedules_next ON report_schedules(is_active, next_run_at);
ALTER TABLE report_schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY report_schedules_isolation ON report_schedules
  USING (account_id = NULLIF(current_setting('app.account_id', true), '')::UUID);

-- Shareable report links (for client delivery)
CREATE TABLE report_shares (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  run_id          UUID NOT NULL REFERENCES report_runs(id) ON DELETE CASCADE,
  account_id      UUID NOT NULL REFERENCES accounts(id),
  share_token     UUID DEFAULT uuid_generate_v4(),
  expires_at      TIMESTAMPTZ DEFAULT NOW() + INTERVAL '7 days',
  view_count      INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_report_shares_token ON report_shares(share_token);

