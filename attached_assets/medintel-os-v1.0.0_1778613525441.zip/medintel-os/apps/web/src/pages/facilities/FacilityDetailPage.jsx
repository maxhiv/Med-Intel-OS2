import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import api from '../../api/client.js';

const SIGNAL_COLORS = { depreciation_flag: '#f59e0b', con_approved: '#00e5a0', nih_grant: '#00c2ff', clinical_trial: '#bc8cff', bond_issuance: '#f59e0b', construction_permit: '#00e5a0', leadership_change: '#f59e0b', default: '#7a94b0' };

export default function FacilityDetailPage() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('overview');

  const { data: r, isLoading } = useQuery({
    queryKey: ['facility', id],
    queryFn: () => api.get(`/facilities/${id}`).then(r => r.data),
  });

  const tabs = ['overview', 'equipment', 'contacts', 'financials', 'intelligence'];

  if (isLoading) return <div style={{ padding: 24, color: '#7a94b0', fontSize: 11 }}>Loading facility data...</div>;
  if (!r) return <div style={{ padding: 24, color: '#ef4444', fontSize: 11 }}>Facility not found</div>;

  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <Link to="/facilities" style={{ fontSize: 10, color: '#0077a8', textDecoration: 'none', letterSpacing: '0.1em' }}>← FACILITIES</Link>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#e2eaf5', margin: '8px 0 4px' }}>{r.name}</h1>
        <div style={{ fontSize: 12, color: '#7a94b0' }}>{r.city}, {r.state} · NPI: {r.npi} · {r.facility_type} · {r.beds ? `${r.beds} beds` : ''}</div>
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
          <span style={{ fontSize: 10, padding: '3px 10px', borderRadius: 20, background: '#00c2ff14', color: '#00c2ff' }}>Score: {r.signal_score}</span>
          {r.cah_designation && <span style={{ fontSize: 10, padding: '3px 10px', borderRadius: 20, background: '#f59e0b14', color: '#f59e0b' }}>CAH</span>}
          {r.teaching_hospital && <span style={{ fontSize: 10, padding: '3px 10px', borderRadius: 20, background: '#bc8cff14', color: '#bc8cff' }}>Teaching</span>}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 2, marginBottom: 20, borderBottom: '1px solid #1e2d47' }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setActiveTab(t)} style={{ background: 'none', border: 'none', borderBottom: `2px solid ${activeTab === t ? '#00c2ff' : 'transparent'}`, color: activeTab === t ? '#00c2ff' : '#7a94b0', padding: '8px 14px', cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', textTransform: 'capitalize', fontWeight: activeTab === t ? 700 : 400 }}>{t}</button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, padding: '16px 20px' }}>
            <div style={{ fontSize: 10, color: '#0077a8', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 12, fontWeight: 700 }}>Purchase Signals</div>
            {r.signals?.length ? r.signals.map(s => (
              <div key={s.id} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid #1e2d4740', alignItems: 'flex-start' }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: SIGNAL_COLORS[s.signal_type] || SIGNAL_COLORS.default, marginTop: 4, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 11, color: '#e2eaf5', fontWeight: 600 }}>{s.signal_type.replace(/_/g, ' ')}</div>
                  <div style={{ fontSize: 10, color: '#7a94b0' }}>{s.signal_value}</div>
                </div>
                <div style={{ marginLeft: 'auto', fontSize: 10, color: '#4b6280' }}>{s.confidence}%</div>
              </div>
            )) : <div style={{ fontSize: 11, color: '#4b6280' }}>No active signals</div>}
          </div>
          <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, padding: '16px 20px' }}>
            <div style={{ fontSize: 10, color: '#0077a8', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 12, fontWeight: 700 }}>Intelligence Summary</div>
            {[
              { l: 'EHR Vendor', v: r.techStack?.ehr_vendor },
              { l: 'HIMSS EMRAM', v: r.techStack?.himss_emram_score ? `Level ${r.techStack.himss_emram_score}` : null },
              { l: 'GPO', v: r.procurement?.gpo_name },
              { l: 'Fiscal Year End', v: r.procurement?.fiscal_year_end },
              { l: 'Active Trials', v: r.research?.active_trials_count },
              { l: 'NIH Grants', v: r.research?.nih_grants_active },
            ].map(({ l, v }) => v ? (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #1e2d4730', fontSize: 11 }}>
                <span style={{ color: '#7a94b0' }}>{l}</span>
                <span style={{ color: '#e2eaf5' }}>{v}</span>
              </div>
            ) : null)}
          </div>
        </div>
      )}

      {activeTab === 'equipment' && (
        <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 80px 100px 80px', padding: '8px 16px', background: '#0a0f1a', borderBottom: '1px solid #1e2d47' }}>
            {['Modality', 'Manufacturer', 'Model', 'Year', 'Depreciated', 'Urgency'].map(h => (
              <div key={h} style={{ fontSize: 9, color: '#4b6280', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{h}</div>
            ))}
          </div>
          {r.equipment?.map((e, i) => (
            <div key={e.id} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 80px 100px 80px', padding: '10px 16px', borderBottom: '1px solid #1e2d4720', background: i % 2 === 0 ? 'transparent' : '#1a22340a' }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#e2eaf5', textTransform: 'capitalize' }}>{e.modality}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{e.manufacturer || '—'}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{e.model || '—'}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{e.install_year || '—'}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: e.pct_depreciated >= 80 ? '#ef4444' : e.pct_depreciated >= 60 ? '#f59e0b' : '#00e5a0' }}>{e.pct_depreciated ? `${e.pct_depreciated}%` : '—'}</div>
              <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 3, background: e.urgency_tier === 'critical' ? '#ef444422' : '#1a2234', color: e.urgency_tier === 'critical' ? '#ef4444' : '#7a94b0', textTransform: 'uppercase' }}>{e.urgency_tier}</span>
            </div>
          ))}
          {!r.equipment?.length && <div style={{ padding: 24, color: '#4b6280', fontSize: 11, textAlign: 'center' }}>No equipment records — trigger HCRIS ingestion</div>}
        </div>
      )}

      {activeTab === 'contacts' && (
        <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1fr 80px 80px', padding: '8px 16px', background: '#0a0f1a', borderBottom: '1px solid #1e2d47' }}>
            {['Name', 'Email', 'Title', 'Score', 'Status'].map(h => (
              <div key={h} style={{ fontSize: 9, color: '#4b6280', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{h}</div>
            ))}
          </div>
          {r.contacts?.map((c, i) => (
            <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1fr 80px 80px', padding: '10px 16px', borderBottom: '1px solid #1e2d4720', background: i % 2 === 0 ? 'transparent' : '#1a22340a', alignItems: 'center' }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#e2eaf5' }}>{c.full_name}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{c.email || <span style={{ color: '#4b6280' }}>No email</span>}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{c.title || '—'}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: c.confidence_score >= 70 ? '#00e5a0' : c.confidence_score >= 40 ? '#f59e0b' : '#7a94b0' }}>{c.confidence_score}</div>
              <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 3, background: c.email_status === 'verified' ? '#00e5a022' : '#1a2234', color: c.email_status === 'verified' ? '#00e5a0' : '#7a94b0', textTransform: 'uppercase' }}>{c.email_status}</span>
            </div>
          ))}
          {!r.contacts?.length && <div style={{ padding: 24, color: '#4b6280', fontSize: 11, textAlign: 'center' }}>No contacts — run enrichment pipeline</div>}
        </div>
      )}
    </div>
  );
}
