import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import api from '../../api/client.js';

const US_STATES = ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'];

export default function FacilitiesPage() {
  const [filters, setFilters] = useState({ state: '', type: '', minScore: '', search: '' });
  const [page, setPage] = useState(0);

  const { data, isLoading } = useQuery({
    queryKey: ['facilities', filters, page],
    queryFn: () => api.get(`/facilities?${new URLSearchParams({ ...filters, limit: 50, offset: page * 50 })}`).then(r => r),
  });

  const F = { select: { background: '#1a2234', border: '1px solid #1e2d47', color: '#e2eaf5', padding: '6px 10px', borderRadius: 4, fontSize: 11, fontFamily: 'inherit', cursor: 'pointer' } };

  return (
    <div>
      <div style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <div style={{ fontSize: 9, color: '#0077a8', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 4 }}>Intelligence Database</div>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: '#e2eaf5', margin: 0 }}>Facilities</h1>
        </div>
        <div style={{ fontSize: 11, color: '#7a94b0' }}>{data?.meta?.total?.toLocaleString() || 0} total</div>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        <input placeholder="Search facility name..." value={filters.search} onChange={e => setFilters(p => ({ ...p, search: e.target.value }))}
          style={{ ...F.select, padding: '6px 12px', flex: 1, minWidth: 200 }} />
        <select value={filters.state} onChange={e => setFilters(p => ({ ...p, state: e.target.value }))} style={F.select}>
          <option value="">All States</option>
          {US_STATES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={filters.type} onChange={e => setFilters(p => ({ ...p, type: e.target.value }))} style={F.select}>
          <option value="">All Types</option>
          <option value="hospital">Hospital</option>
          <option value="imaging_center">Imaging Center</option>
          <option value="asc">ASC</option>
          <option value="health_system">Health System</option>
        </select>
        <select value={filters.minScore} onChange={e => setFilters(p => ({ ...p, minScore: e.target.value }))} style={F.select}>
          <option value="">Any Score</option>
          <option value="70">70+ (Hot)</option>
          <option value="50">50+ (Warm)</option>
          <option value="30">30+ (Watch)</option>
        </select>
      </div>

      <div style={{ background: '#111827', border: '1px solid #1e2d47', borderRadius: 8, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 80px 70px 80px 80px 80px', padding: '8px 16px', background: '#0a0f1a', borderBottom: '1px solid #1e2d47' }}>
          {['Facility', 'Location', 'Beds', 'Score', 'Signals', 'Contacts', 'Type'].map(h => (
            <div key={h} style={{ fontSize: 9, color: '#4b6280', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{h}</div>
          ))}
        </div>

        {isLoading ? (
          <div style={{ padding: 24, color: '#7a94b0', textAlign: 'center', fontSize: 11 }}>Loading facilities...</div>
        ) : (
          (data?.data || []).map((f, i) => (
            <div key={f.id} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 80px 70px 80px 80px 80px', padding: '10px 16px', borderBottom: '1px solid #1e2d4720', alignItems: 'center', background: i % 2 === 0 ? 'transparent' : '#1a22340a' }}>
              <Link to={`/facilities/${f.id}`} style={{ color: '#e2eaf5', textDecoration: 'none', fontSize: 12, fontWeight: 600 }}>{f.name}</Link>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{f.city}, {f.state}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{f.beds || '—'}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: f.signal_score >= 70 ? '#00e5a0' : f.signal_score >= 40 ? '#f59e0b' : '#7a94b0' }}>{f.signal_score}</div>
              <div style={{ fontSize: 11, color: '#00c2ff' }}>{f.signal_count || 0}</div>
              <div style={{ fontSize: 11, color: '#7a94b0' }}>{f.contact_count || 0}</div>
              <div style={{ fontSize: 9, color: '#4b6280', textTransform: 'uppercase' }}>{f.facility_type}</div>
            </div>
          ))
        )}
      </div>

      {data?.meta?.total > 50 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 16 }}>
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} style={{ background: '#1a2234', border: '1px solid #1e2d47', color: '#7a94b0', padding: '6px 14px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>← Prev</button>
          <span style={{ fontSize: 11, color: '#7a94b0', padding: '6px 0' }}>Page {page + 1}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * 50 >= (data?.meta?.total || 0)} style={{ background: '#1a2234', border: '1px solid #1e2d47', color: '#7a94b0', padding: '6px 14px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>Next →</button>
        </div>
      )}
    </div>
  );
}
