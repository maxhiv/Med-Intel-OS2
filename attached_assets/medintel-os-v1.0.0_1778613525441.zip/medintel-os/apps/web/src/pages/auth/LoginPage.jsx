import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { useAuthStore } from '../../store/authStore.js';
import api from '../../api/client.js';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { setAuth } = useAuthStore();
  const nav = useNavigate();

  const loginMutation = useMutation({
    mutationFn: () => api.post('/auth/login', { email, password }),
    onSuccess: (data) => { setAuth(data.data.token, data.data.user); nav('/dashboard'); },
  });

  const S = { input: { background: '#1a2234', border: '1px solid #1e2d47', color: '#e2eaf5', padding: '10px 14px', borderRadius: 6, fontSize: 12, fontFamily: 'inherit', width: '100%', outline: 'none', boxSizing: 'border-box' } };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0f1a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'JetBrains Mono, monospace' }}>
      <div style={{ width: 380, background: '#111827', border: '1px solid #1e2d47', borderRadius: 12, padding: 32 }}>
        <div style={{ marginBottom: 28, textAlign: 'center' }}>
          <div style={{ fontSize: 9, color: '#0077a8', letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: 8 }}>Hansen Holdings</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#00c2ff' }}>MedIntel OS</div>
          <div style={{ fontSize: 11, color: '#7a94b0', marginTop: 4 }}>Medical Equipment Sales Intelligence</div>
        </div>

        {loginMutation.error && (
          <div style={{ background: '#ef444420', border: '1px solid #ef444444', borderRadius: 6, padding: '10px 14px', marginBottom: 16, fontSize: 11, color: '#ef4444' }}>
            {loginMutation.error.message}
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <div style={{ fontSize: 10, color: '#7a94b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Email</div>
            <input style={S.input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@example.com" autoFocus />
          </div>
          <div>
            <div style={{ fontSize: 10, color: '#7a94b0', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Password</div>
            <input style={S.input} type="password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && loginMutation.mutate()} />
          </div>
          <button
            onClick={() => loginMutation.mutate()}
            disabled={loginMutation.isPending}
            style={{ background: '#00c2ff', color: '#0a0f1a', padding: '11px', borderRadius: 6, border: 'none', cursor: loginMutation.isPending ? 'not-allowed' : 'pointer', fontSize: 12, fontFamily: 'inherit', fontWeight: 700, marginTop: 4 }}
          >
            {loginMutation.isPending ? 'Signing in...' : 'Sign In →'}
          </button>
        </div>
      </div>
    </div>
  );
}
