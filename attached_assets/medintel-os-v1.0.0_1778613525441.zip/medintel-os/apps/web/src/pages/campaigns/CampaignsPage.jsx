import React from 'react';
export default function Page() {
  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 9, color: '#0077a8', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 4 }}>MedIntel OS</div>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#e2eaf5', margin: '0 0 4px' }}>Campaigns</h1>
        <p style={{ fontSize: 11, color: '#7a94b0', margin: 0 }}>Outreach campaigns and cohort management</p>
      </div>
      <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, padding: 24, color: '#4b6280', fontSize: 11 }}>
        Full implementation coming — scaffold ready.
      </div>
    </div>
  );
}
