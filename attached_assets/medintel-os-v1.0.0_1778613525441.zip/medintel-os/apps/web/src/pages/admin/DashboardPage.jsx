import React from 'react';
import { useQuery } from '@tanstack/react-query';
import api from '../../api/client.js';
import { useAuthStore } from '../../store/authStore.js';

function StatCard({ label, value, color = '#00c2ff', sub }) {
  return (
    <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderTop: `3px solid ${color}`, borderRadius: 8, padding: '16px 20px' }}>
      <div style={{ fontSize: 9, color: '#7a94b0', letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color, fontFamily: 'JetBrains Mono, monospace' }}>{value ?? '—'}</div>
      {sub && <div style={{ fontSize: 10, color: '#4b6280', marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

export default function DashboardPage() {
  const { isPlatformAdmin } = useAuthStore();
  const { data: stats } = useQuery({
    queryKey: ['platform-stats'],
    queryFn: () => isPlatformAdmin() ? api.get('/admin/stats').then(r => r.data) : null,
    enabled: isPlatformAdmin(),
  });

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 10, color: '#0077a8', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 4 }}>Platform Overview</div>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#e2eaf5', margin: 0 }}>Intelligence Dashboard</h1>
      </div>

      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
          <StatCard label="Total Facilities" value={parseInt(stats.total_facilities).toLocaleString()} color="#00c2ff" />
          <StatCard label="Verified Contacts" value={parseInt(stats.verified_contacts).toLocaleString()} color="#00e5a0" sub={`of ${parseInt(stats.total_contacts).toLocaleString()} total`} />
          <StatCard label="Active Signals" value={parseInt(stats.active_signals).toLocaleString()} color="#f59e0b" />
          <StatCard label="Pending Drafts" value={parseInt(stats.pending_drafts).toLocaleString()} color="#bc8cff" sub="awaiting CRM sync" />
        </div>
      )}

      <div style={{ background: '#1a2234', border: '1px solid #00e5a033', borderLeft: '4px solid #00e5a0', borderRadius: 8, padding: '16px 20px', marginBottom: 20 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#00e5a0', marginBottom: 6 }}>✅ Platform Operational</div>
        <div style={{ fontSize: 11, color: '#7a94b0', lineHeight: 1.7 }}>
          Batch sync runs daily at 2am CT. Enrichment queue processes every 30 minutes.
          No outreach is ever sent automatically — all drafts require rep review in CRM.
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, padding: '16px 20px' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#e2eaf5', marginBottom: 12 }}>Active Accounts</div>
          <div style={{ fontSize: 11, color: '#7a94b0' }}>{stats?.active_accounts || 0} active client accounts</div>
        </div>
        <div style={{ background: '#1a2234', border: '1px solid #1e2d47', borderRadius: 8, padding: '16px 20px' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#e2eaf5', marginBottom: 12 }}>Batches Today</div>
          <div style={{ fontSize: 11, color: '#7a94b0' }}>{stats?.batches_today || 0} CRM sync batches run today</div>
        </div>
      </div>
    </div>
  );
}
