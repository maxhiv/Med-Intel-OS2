/**
 * Enrichment Source Approval Page
 * Platform admin (Hansen Holdings / Max) uses this to approve paid data sources.
 * No paid source ever runs until explicitly approved here.
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '../../api/client.js';

const SOURCE_META = {
  apollo:           { label: 'Apollo.io',          cost: '$49/mo + $0.01–0.05/contact', use: 'Email + contact enrichment — waterfall position 1', tier: 'paid' },
  netrows:          { label: 'Netrows (LinkedIn)',  cost: '€49/mo + €0.005/request',      use: 'LinkedIn profiles — replaces defunct Proxycurl',       tier: 'paid' },
  zerobounce:       { label: 'ZeroBounce',          cost: '$0.0039/email',               use: 'SMTP email verification (99.6% accuracy)',              tier: 'paid' },
  bouncer:          { label: 'Bouncer',             cost: '$0.006/email',                use: 'Catch-all email resolution — hospital domains',         tier: 'paid' },
  twilio:           { label: 'Twilio Lookup',       cost: '$0.005/lookup',               use: 'Phone validation: line type, carrier, ported',          tier: 'paid' },
  people_data_labs: { label: 'People Data Labs',    cost: '$0.04/record',                use: 'Contact context: career history, education',            tier: 'paid' },
  zoominfo:         { label: 'ZoomInfo',            cost: '$15K+/yr (enterprise)',        use: 'Enterprise: org charts, GPO data, direct dials',        tier: 'enterprise' },
  definitive_hc:    { label: 'Definitive Healthcare', cost: '$30K+/yr',                  use: 'GPO membership, installed base, purchase contacts',      tier: 'enterprise' },
  openpermit:       { label: 'OpenPermit',          cost: 'Free→$99+/mo',               use: 'Building permits: construction/expansion signals',       tier: 'freemium' },
};

export default function EnrichmentApprovalPage() {
  const qc = useQueryClient();
  const [approving, setApproving] = useState(null);
  const [budgetInput, setBudgetInput] = useState('');
  const [notes, setNotes] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['enrichment-approvals'],
    queryFn: () => api.get('/admin/enrichment-approvals').then(r => r.data),
  });

  const approveMutation = useMutation({
    mutationFn: ({ source, monthlyBudgetLimit, notes }) =>
      api.post(`/admin/enrichment-approvals/${source}/approve`, { monthlyBudgetLimit, notes }),
    onSuccess: () => { qc.invalidateQueries(['enrichment-approvals']); setApproving(null); },
  });

  const revokeMutation = useMutation({
    mutationFn: (source) => api.post(`/admin/enrichment-approvals/${source}/revoke`),
    onSuccess: () => qc.invalidateQueries(['enrichment-approvals']),
  });

  if (isLoading) return <div className="p-8 text-gray-400">Loading...</div>;

  const statusColor = (source) => {
    if (!source.env_key_present) return 'bg-gray-800 text-gray-500';
    if (source.approved && source.env_enabled) return 'bg-green-900/40 text-green-400';
    if (source.approved && !source.env_enabled) return 'bg-yellow-900/40 text-yellow-400';
    return 'bg-red-900/20 text-red-400';
  };

  const statusLabel = (source) => {
    if (!source.env_key_present) return '⬜ No API key';
    if (source.approved && source.env_enabled) return '✅ Active';
    if (source.approved && !source.env_enabled) return '⚠ Approved (env disabled)';
    return '🔴 Awaiting approval';
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0f1a', padding: '32px', color: '#e2eaf5', fontFamily: 'JetBrains Mono, monospace' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 11, color: '#0077a8', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 6 }}>
            Platform Admin · Hansen Holdings L0
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: '#00c2ff', marginBottom: 6 }}>
            Enrichment Source Approvals
          </h1>
          <p style={{ fontSize: 12, color: '#7a94b0', lineHeight: 1.7, maxWidth: 620 }}>
            No paid enrichment source is ever used until you explicitly approve it here.
            Both this approval AND the environment variable must be enabled for a source to activate.
          </p>
        </div>

        {/* Two-gate explanation */}
        <div style={{ background: '#0077a8/20', border: '1px solid #0077a844', borderRadius: 8, padding: '14px 18px', marginBottom: 24, fontSize: 11, color: '#7a94b0' }}>
          <strong style={{ color: '#00c2ff' }}>Two-gate system: </strong>
          Gate 1: Set the <code>*_API_KEY</code> and <code>*_ENABLED=true</code> in your .env file. &nbsp;
          Gate 2: Click "Approve" below. Both must pass before a source can run.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {(data || []).map((source) => {
            const meta = SOURCE_META[source.source] || {};
            const isActive = source.approved && source.env_enabled;

            return (
              <div key={source.source} style={{
                background: '#1a2234',
                border: `1px solid ${isActive ? '#00e5a044' : '#1e2d47'}`,
                borderLeft: `4px solid ${isActive ? '#00e5a0' : source.approved ? '#f59e0b' : '#ef444444'}`,
                borderRadius: 8,
                padding: '16px 20px',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
                      <span style={{ fontSize: 14, fontWeight: 700, color: '#e2eaf5' }}>{meta.label || source.source}</span>
                      <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 3, ...Object.fromEntries(statusColor(source).split(' ').map(c => {
                        if (c.startsWith('bg-')) return ['background', c.replace('bg-', '').replace('/', '/').replace('900', '#0d1117').replace('800', '#1a2234')];
                        if (c.startsWith('text-')) return ['color', c.replace('text-', '').replace('green-400', '#00e5a0').replace('yellow-400', '#f59e0b').replace('red-400', '#ef4444').replace('gray-500', '#6b7280')];
                        return [c, c];
                      })) }}>{statusLabel(source)}</span>
                    </div>
                    <div style={{ fontSize: 11, color: '#7a94b0' }}>
                      <span style={{ color: '#00c2ff' }}>{meta.cost}</span> · {meta.use}
                    </div>
                    {source.approved_at && (
                      <div style={{ fontSize: 10, color: '#4b6280', marginTop: 4 }}>
                        Approved: {new Date(source.approved_at).toLocaleDateString()}
                        {source.monthly_budget_limit && ` · Budget: $${(source.monthly_budget_limit / 100).toFixed(0)}/mo`}
                        {source.notes && ` · Note: ${source.notes}`}
                      </div>
                    )}
                  </div>

                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {!source.env_key_present && (
                      <span style={{ fontSize: 10, color: '#6b7280' }}>Set API key in .env first</span>
                    )}
                    {source.env_key_present && !source.approved && (
                      <button
                        onClick={() => setApproving(source.source)}
                        style={{ background: '#00c2ff22', border: '1px solid #00c2ff', color: '#00c2ff', padding: '6px 16px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', fontWeight: 700 }}
                      >
                        Approve
                      </button>
                    )}
                    {source.approved && (
                      <button
                        onClick={() => revokeMutation.mutate(source.source)}
                        style={{ background: '#ef444422', border: '1px solid #ef444466', color: '#ef4444', padding: '6px 14px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                </div>

                {/* Approval modal inline */}
                {approving === source.source && (
                  <div style={{ marginTop: 14, padding: '14px', background: '#0a0f1a', borderRadius: 6, border: '1px solid #00c2ff33' }}>
                    <div style={{ fontSize: 11, color: '#7a94b0', marginBottom: 10 }}>
                      Approve <strong style={{ color: '#e2eaf5' }}>{meta.label}</strong> for enrichment?
                    </div>
                    <div style={{ display: 'flex', gap: 12, marginBottom: 10, flexWrap: 'wrap' }}>
                      <input
                        placeholder="Monthly budget limit ($)"
                        value={budgetInput}
                        onChange={e => setBudgetInput(e.target.value)}
                        style={{ background: '#1a2234', border: '1px solid #1e2d47', color: '#e2eaf5', padding: '6px 12px', borderRadius: 4, fontSize: 11, fontFamily: 'inherit', width: 200 }}
                      />
                      <input
                        placeholder="Notes (optional)"
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                        style={{ background: '#1a2234', border: '1px solid #1e2d47', color: '#e2eaf5', padding: '6px 12px', borderRadius: 4, fontSize: 11, fontFamily: 'inherit', flex: 1 }}
                      />
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => approveMutation.mutate({
                          source: source.source,
                          monthlyBudgetLimit: budgetInput ? parseInt(budgetInput) * 100 : null,
                          notes,
                        })}
                        style={{ background: '#00c2ff', color: '#0a0f1a', padding: '7px 18px', borderRadius: 4, border: 'none', cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', fontWeight: 700 }}
                      >
                        ✅ Confirm Approval
                      </button>
                      <button
                        onClick={() => setApproving(null)}
                        style={{ background: 'none', border: '1px solid #1e2d47', color: '#7a94b0', padding: '7px 14px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
