import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore.js';
import AppLayout from './components/layout/AppLayout.jsx';
import LoadingScreen from './components/ui/LoadingScreen.jsx';

// Lazy-load pages for code splitting
const LoginPage = lazy(() => import('./pages/auth/LoginPage.jsx'));
const DashboardPage = lazy(() => import('./pages/admin/DashboardPage.jsx'));
const FacilitiesPage = lazy(() => import('./pages/facilities/FacilitiesPage.jsx'));
const FacilityDetailPage = lazy(() => import('./pages/facilities/FacilityDetailPage.jsx'));
const ContactsPage = lazy(() => import('./pages/contacts/ContactsPage.jsx'));
const CampaignsPage = lazy(() => import('./pages/campaigns/CampaignsPage.jsx'));
const SequencesPage = lazy(() => import('./pages/sequences/SequencesPage.jsx'));
const ReportsPage = lazy(() => import('./pages/reports/ReportsPage.jsx'));
const BatchesPage = lazy(() => import('./pages/batches/BatchesPage.jsx'));
const SettingsPage = lazy(() => import('./pages/settings/SettingsPage.jsx'));
const AdminPage = lazy(() => import('./pages/admin/AdminPage.jsx'));
const EnrichmentApprovalPage = lazy(() => import('./pages/admin/EnrichmentApprovalPage.jsx'));

function PrivateRoute({ children }) {
  const { token } = useAuthStore();
  return token ? children : <Navigate to="/login" replace />;
}

function AdminRoute({ children }) {
  const { user } = useAuthStore();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'platform_admin') return <Navigate to="/dashboard" replace />;
  return children;
}

export default function App() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<PrivateRoute><AppLayout /></PrivateRoute>}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="facilities" element={<FacilitiesPage />} />
          <Route path="facilities/:id" element={<FacilityDetailPage />} />
          <Route path="contacts" element={<ContactsPage />} />
          <Route path="campaigns" element={<CampaignsPage />} />
          <Route path="sequences" element={<SequencesPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="batches" element={<BatchesPage />} />
          <Route path="settings" element={<SettingsPage />} />
          {/* Platform admin routes */}
          <Route path="admin" element={<AdminRoute><AdminPage /></AdminRoute>} />
          <Route path="admin/enrichment" element={<AdminRoute><EnrichmentApprovalPage /></AdminRoute>} />
        </Route>
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  );
}
