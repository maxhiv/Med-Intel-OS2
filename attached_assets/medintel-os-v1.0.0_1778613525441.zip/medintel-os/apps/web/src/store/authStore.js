import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      accountId: null,

      setAuth: (token, user) => set({
        token,
        user,
        accountId: user?.accountId || null,
      }),

      clearAuth: () => set({ token: null, user: null, accountId: null }),

      isPlatformAdmin: () => get().user?.role === 'platform_admin',
      isAccountAdmin: () => ['platform_admin', 'account_admin'].includes(get().user?.role),
    }),
    { name: 'medintel-auth', partialize: (state) => ({ token: state.token, user: state.user }) }
  )
);
