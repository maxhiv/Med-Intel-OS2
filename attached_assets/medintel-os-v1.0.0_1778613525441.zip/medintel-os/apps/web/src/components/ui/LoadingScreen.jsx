import React from 'react';
export default function LoadingScreen() {
  return (
    <div style={{ minHeight: '100vh', background: '#0a0f1a', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
      <div style={{ fontSize: 10, color: '#0077a8', letterSpacing: '0.3em', textTransform: 'uppercase', animation: 'pulse 1.5s ease-in-out infinite' }}>MedIntel OS</div>
      <div style={{ fontSize: 20, color: '#00c2ff' }}>⬡</div>
      <div style={{ fontSize: 11, color: '#7a94b0' }}>Loading platform...</div>
    </div>
  );
}
