import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore.js';

const NAV_ITEMS = [
  { path: '/dashboard',    label: 'Dashboard',       icon: '⬡' },
  { path: '/facilities',   label: 'Facilities',      icon: '🏛' },
  { path: '/contacts',     label: 'Contacts',        icon: '👤' },
  { path: '/campaigns',    label: 'Campaigns',       icon: '📡' },
  { path: '/sequences',    label: 'Sequences',       icon: '✉' },
  { path: '/batches',      label: 'Batch Sync',      icon: '↑' },
  { path: '/reports',      label: 'Reports',         icon: '▤' },
  { path: '/settings',     label: 'Settings',        icon: '⚙' },
];

const ADMIN_ITEMS = [
  { path: '/admin',            label: 'Admin',           icon: '⬡' },
  { path: '/admin/enrichment', label: 'Enrichment Gates', icon: '🔑' },
];

const C = { bg: '#111827', border: '#1e2d47', text: '#7a94b0', active: '#00c2ff', hover: '#1a2234' };

export default function Sidebar({ open }) {
  const { isPlatformAdmin } = useAuthStore();
  const loc = useLocation();

  if (!open) return null;

  return (
    <aside style={{ width: 220, minHeight: '100vh', background: C.bg, borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      <div style={{ padding: '20px 16px 16px', borderBottom: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 10, color: '#0077a8', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 4 }}>MedIntel OS</div>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#00c2ff', letterSpacing: '-0.02em' }}>Intelligence Platform</div>
      </div>
      <nav style={{ flex: 1, padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV_ITEMS.map(item => (
          <NavItem key={item.path} {...item} active={loc.pathname.startsWith(item.path)} />
        ))}
        {isPlatformAdmin() && (
          <>
            <div style={{ height: 1, background: C.border, margin: '8px 0' }} />
            <div style={{ fontSize: 9, color: '#4b6280', letterSpacing: '0.15em', padding: '4px 10px', textTransform: 'uppercase' }}>Hansen Holdings L0</div>
            {ADMIN_ITEMS.map(item => (
              <NavItem key={item.path} {...item} active={loc.pathname === item.path} />
            ))}
          </>
        )}
      </nav>
      <div style={{ padding: '12px 16px', borderTop: `1px solid ${C.border}`, fontSize: 9, color: '#4b6280' }}>v1.0.0 · Hansen Holdings</div>
    </aside>
  );
}

function NavItem({ path, label, icon, active }) {
  return (
    <NavLink to={path} style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px',
      borderRadius: 6, textDecoration: 'none',
      background: active ? '#00c2ff14' : 'transparent',
      color: active ? '#00c2ff' : '#7a94b0',
      fontSize: 12, fontFamily: 'inherit', fontWeight: active ? 600 : 400,
      borderLeft: active ? '2px solid #00c2ff' : '2px solid transparent',
    }}>
      <span style={{ fontSize: 14 }}>{icon}</span>
      {label}
    </NavLink>
  );
}
