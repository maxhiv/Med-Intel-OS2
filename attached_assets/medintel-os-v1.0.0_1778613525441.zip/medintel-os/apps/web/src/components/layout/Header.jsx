import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore.js';

export default function Header({ onMenuToggle }) {
  const { user, clearAuth } = useAuthStore();
  const nav = useNavigate();

  const logout = () => { clearAuth(); nav('/login'); };

  return (
    <header style={{ height: 52, background: '#111827', borderBottom: '1px solid #1e2d47', display: 'flex', alignItems: 'center', padding: '0 20px', gap: 12, flexShrink: 0 }}>
      <button onClick={onMenuToggle} style={{ background: 'none', border: 'none', color: '#7a94b0', cursor: 'pointer', fontSize: 18, lineHeight: 1 }}>☰</button>
      <div style={{ flex: 1 }} />
      <div style={{ fontSize: 11, color: '#7a94b0' }}>{user?.email}</div>
      <span style={{ fontSize: 9, padding: '2px 8px', borderRadius: 3, background: '#00c2ff14', color: '#00c2ff', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{user?.role?.replace('_', ' ')}</span>
      <button onClick={logout} style={{ background: 'none', border: '1px solid #1e2d47', color: '#7a94b0', padding: '4px 10px', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>Logout</button>
    </header>
  );
}
