/**
 * API Client — wraps fetch with auth headers, base URL, and error handling
 */
import { useAuthStore } from '../store/authStore.js';

const BASE_URL = import.meta.env.VITE_API_URL || '/api';

class ApiClient {
  async request(method, path, body = null, options = {}) {
    const { token } = useAuthStore.getState();

    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    };

    const resp = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
      signal: options.signal,
    });

    if (resp.status === 401) {
      useAuthStore.getState().clearAuth();
      window.location.href = '/login';
      return;
    }

    const data = await resp.json();

    if (!resp.ok) {
      const error = new Error(data.error?.message || 'Request failed');
      error.code = data.error?.code;
      error.status = resp.status;
      throw error;
    }

    return data;
  }

  get(path, options) { return this.request('GET', path, null, options); }
  post(path, body, options) { return this.request('POST', path, body, options); }
  patch(path, body, options) { return this.request('PATCH', path, body, options); }
  put(path, body, options) { return this.request('PUT', path, body, options); }
  delete(path, options) { return this.request('DELETE', path, null, options); }
}

export const api = new ApiClient();
export default api;
