export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { mono: ['"JetBrains Mono"', 'monospace'] },
      colors: {
        brand: { DEFAULT: '#00c2ff', dim: '#0077a8' },
        surface: { DEFAULT: '#111827', card: '#1a2234', deep: '#0a0f1a' },
        border: { DEFAULT: '#1e2d47' },
        signal: { green: '#00e5a0', amber: '#f59e0b', red: '#ef4444', purple: '#bc8cff' },
      },
    },
  },
  plugins: [],
};
