/**
 * Job Scheduler — Cron-based background jobs
 * All jobs are idempotent and logged.
 */
import cron from 'node-cron';
import { logger } from '../config/logger.js';

export function startScheduledJobs() {
  logger.info('⏰ Starting scheduled jobs...');

  // Daily batch sync — 2am Central time
  cron.schedule('0 2 * * *', async () => {
    logger.info('JOB: Daily CRM batch sync');
    try {
      const { batchSyncProcessor } = await import('../services/batch/BatchSyncProcessor.js');
      await batchSyncProcessor.runDailyBatches();
    } catch (err) { logger.error('Batch sync job failed:', err.message); }
  }, { timezone: 'America/Chicago' });

  // Signal scoring update — every 6 hours
  cron.schedule('0 */6 * * *', async () => {
    logger.info('JOB: Signal score recompute');
    try {
      const { recomputeSignalScores } = await import('../services/intelligence/SignalScorer.js');
      await recomputeSignalScores();
    } catch (err) { logger.error('Signal scoring job failed:', err.message); }
  });

  // Contact enrichment queue processor — every 30 min
  cron.schedule('*/30 * * * *', async () => {
    logger.info('JOB: Enrichment queue');
    try {
      const { processEnrichmentQueue } = await import('../workers/enrichmentWorker.js');
      await processEnrichmentQueue(25);  // process up to 25 contacts per run
    } catch (err) { logger.error('Enrichment queue job failed:', err.message); }
  });

  // CMS / NPPES data refresh — weekly Sunday 3am
  cron.schedule('0 3 * * 0', async () => {
    logger.info('JOB: CMS/NPPES weekly refresh');
    try {
      const { NPPESIngestionService } = await import('../services/ingestion/NPPESIngestionService.js');
      await new NPPESIngestionService().checkForUpdates();
    } catch (err) { logger.error('NPPES refresh failed:', err.message); }
  }, { timezone: 'America/Chicago' });

  // CON filings scrape — daily 4am
  cron.schedule('0 4 * * *', async () => {
    logger.info('JOB: CON filings scrape');
    try {
      const { CONIngestionService } = await import('../services/ingestion/CONIngestionService.js');
      await new CONIngestionService().scrapeNewFilings();
    } catch (err) { logger.error('CON scrape failed:', err.message); }
  }, { timezone: 'America/Chicago' });

  // Scheduled report runner — every 5 min (checks for due reports)
  cron.schedule('*/5 * * * *', async () => {
    try {
      const { runDueReports } = await import('../services/reports/ReportScheduler.js');
      await runDueReports();
    } catch (err) { logger.error('Report scheduler failed:', err.message); }
  });

  // Enrichment budget reset — 1st of month
  cron.schedule('0 0 1 * *', async () => {
    logger.info('JOB: Reset enrichment monthly budgets');
    const db = (await import('../config/database.js')).default;
    await db('enrichment_source_approvals').update({
      current_month_spend: 0,
      last_reset_at: db.fn.now(),
    });
  });

  logger.info('✅ All scheduled jobs registered');
}
