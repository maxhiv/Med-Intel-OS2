import { Router } from 'express';
import authRoutes from './auth.routes.js';
import facilitiesRoutes from './facilities.routes.js';
import contactsRoutes from './contacts.routes.js';
import campaignsRoutes from './campaigns.routes.js';
import sequencesRoutes from './sequences.routes.js';
import enrichmentRoutes from './enrichment.routes.js';
import batchRoutes from './batch.routes.js';
import reportsRoutes from './reports.routes.js';
import adminRoutes from './admin.routes.js';
import accountsRoutes from './accounts.routes.js';
import webhooksRoutes from './webhooks.routes.js';
import ingestionRoutes from './ingestion.routes.js';

const router = Router();

router.use('/auth', authRoutes);
router.use('/facilities', facilitiesRoutes);
router.use('/contacts', contactsRoutes);
router.use('/campaigns', campaignsRoutes);
router.use('/sequences', sequencesRoutes);
router.use('/enrichment', enrichmentRoutes);
router.use('/batches', batchRoutes);
router.use('/reports', reportsRoutes);
router.use('/admin', adminRoutes);
router.use('/accounts', accountsRoutes);
router.use('/webhooks', webhooksRoutes);
router.use('/ingestion', ingestionRoutes);

export default router;
