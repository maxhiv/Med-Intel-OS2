import { Router } from 'express';
import { authenticate, requireAccountAdmin, requirePlatformAdmin } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import * as controller from '../controllers/webhooks.controller.js';

const router = Router();

// All routes below require authentication
router.use(authenticate);

// ── Routes for webhooks ──
router.get('/', asyncHandler(controller.list));
router.get('/:id', asyncHandler(controller.getById));
router.post('/', asyncHandler(controller.create));
router.patch('/:id', asyncHandler(controller.update));
router.delete('/:id', asyncHandler(controller.remove));

export default router;
