import { Router } from 'express';
import { authenticate, requirePlatformAdmin } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import * as admin from '../controllers/admin.controller.js';

const router = Router();
router.use(authenticate, requirePlatformAdmin);

// Accounts management
router.get('/accounts', asyncHandler(admin.listAccounts));
router.post('/accounts', asyncHandler(admin.createAccount));
router.patch('/accounts/:id', asyncHandler(admin.updateAccount));
router.delete('/accounts/:id', asyncHandler(admin.suspendAccount));

// Users
router.get('/users', asyncHandler(admin.listUsers));
router.post('/users', asyncHandler(admin.createUser));

// ──────────────────────────────────────────────
// ENRICHMENT SOURCE APPROVALS
// Platform admin must explicitly approve each paid source.
// ──────────────────────────────────────────────
router.get('/enrichment-approvals', asyncHandler(admin.listEnrichmentApprovals));
router.post('/enrichment-approvals/:source/approve', asyncHandler(admin.approveEnrichmentSource));
router.post('/enrichment-approvals/:source/revoke', asyncHandler(admin.revokeEnrichmentSource));
router.patch('/enrichment-approvals/:source/budget', asyncHandler(admin.setEnrichmentBudget));

// Platform stats
router.get('/stats', asyncHandler(admin.platformStats));
router.get('/ingestion-status', asyncHandler(admin.ingestionStatus));

export default router;
