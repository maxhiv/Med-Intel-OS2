/**
 * JWT Authentication Middleware
 * - Verifies JWT
 * - Loads user + account
 * - Sets PostgreSQL RLS session variable (app.account_id)
 */
import jwt from 'jsonwebtoken';
import { config } from '../config/env.js';
import db from '../config/database.js';
import { AppError } from './errorHandler.js';

export async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      throw new AppError('No token provided', 401, 'UNAUTHENTICATED');
    }

    const token = authHeader.substring(7);
    const decoded = jwt.verify(token, config.JWT_SECRET);

    // Load user from DB
    const user = await db('users')
      .where({ id: decoded.sub, is_active: true })
      .first();

    if (!user) throw new AppError('User not found or inactive', 401, 'UNAUTHENTICATED');

    req.user = user;
    req.accountId = user.account_id;    // null for platform_admin
    req.isPlatformAdmin = user.role === 'platform_admin';

    // Set RLS context for tenant-scoped queries
    // This fires for every request so tenant data never bleeds across
    if (req.accountId) {
      req.db = {
        async raw(sql, bindings) {
          const client = await db.client.acquireConnection();
          try {
            await client.query(`SET LOCAL app.account_id = '${req.accountId}'`);
            return db.raw(sql, bindings);
          } finally {
            db.client.releaseConnection(client);
          }
        }
      };
    }

    next();
  } catch (err) {
    if (err.name === 'JsonWebTokenError') return next(new AppError('Invalid token', 401, 'INVALID_TOKEN'));
    if (err.name === 'TokenExpiredError') return next(new AppError('Token expired', 401, 'TOKEN_EXPIRED'));
    next(err);
  }
}

/**
 * Require specific role(s)
 */
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return next(new AppError('Unauthenticated', 401));
    if (!roles.includes(req.user.role)) {
      return next(new AppError(`Requires role: ${roles.join(' or ')}`, 403, 'FORBIDDEN'));
    }
    next();
  };
}

export const requirePlatformAdmin = requireRole('platform_admin');
export const requireAccountAdmin = requireRole('platform_admin', 'account_admin');

/**
 * Set RLS context on a Knex query builder
 * Use this in service layer: await withRLS(req.accountId, (trx) => trx('campaigns').select())
 */
export async function withRLS(accountId, fn) {
  return db.transaction(async (trx) => {
    if (accountId) {
      await trx.raw(`SET LOCAL app.account_id = ?`, [accountId]);
    }
    return fn(trx);
  });
}
