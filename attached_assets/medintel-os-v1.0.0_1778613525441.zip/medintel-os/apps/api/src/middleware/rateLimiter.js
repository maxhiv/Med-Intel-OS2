import rateLimit from 'express-rate-limit';
import { AppError } from './errorHandler.js';

export function createRateLimiter(options = {}) {
  return rateLimit({
    windowMs: options.windowMs || 15 * 60 * 1000,
    max: options.max || 500,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => req.user?.id || req.ip,
    handler: (req, res, next, options) => {
      next(new AppError(options.message || 'Too many requests, please slow down', 429, 'RATE_LIMIT_EXCEEDED'));
    },
    ...options,
  });
}
