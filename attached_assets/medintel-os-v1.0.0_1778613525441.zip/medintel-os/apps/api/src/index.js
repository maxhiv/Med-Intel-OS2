/**
 * MedIntel OS — API Server Entry Point
 * Express + PostgreSQL + Redis
 */
import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import morgan from 'morgan';

import { config } from './config/env.js';
import { logger } from './config/logger.js';
import { checkDatabaseConnection } from './config/database.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { createRateLimiter } from './middleware/rateLimiter.js';
import routes from './routes/index.js';
import { startScheduledJobs } from './jobs/scheduler.js';

const app = express();

// ── Security ─────────────────────────────────────────────────────────────────
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

app.use(cors({
  origin: config.NODE_ENV === 'production'
    ? [config.WEB_URL].filter(Boolean)
    : ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Account-ID'],
}));

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('combined', { stream: { write: (msg) => logger.http(msg.trim()) } }));

// Rate limiting
app.use('/api/', createRateLimiter({ windowMs: 15 * 60 * 1000, max: 500 }));
app.use('/api/auth/', createRateLimiter({ windowMs: 15 * 60 * 1000, max: 20, message: 'Too many auth attempts' }));

// ── Health Check ──────────────────────────────────────────────────────────────
app.get('/health', async (req, res) => {
  const dbOk = await checkDatabaseConnection();
  const status = dbOk ? 'healthy' : 'degraded';
  res.status(dbOk ? 200 : 503).json({
    status,
    version: '1.0.0',
    environment: config.NODE_ENV,
    timestamp: new Date().toISOString(),
    services: { database: dbOk ? 'connected' : 'error' },
  });
});

// ── API Routes ────────────────────────────────────────────────────────────────
app.use('/api', routes);

// ── Error Handling ────────────────────────────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  const dbOk = await checkDatabaseConnection();
  if (!dbOk) {
    logger.error('Cannot start: database unavailable');
    process.exit(1);
  }

  app.listen(config.PORT, () => {
    logger.info(`🚀 MedIntel OS API running on port ${config.PORT} [${config.NODE_ENV}]`);
    logger.info(`📡 Health: http://localhost:${config.PORT}/health`);
  });

  if (config.NODE_ENV !== 'test') {
    startScheduledJobs();
  }
}

boot().catch((err) => {
  logger.error('Fatal boot error:', err);
  process.exit(1);
});

export default app;
