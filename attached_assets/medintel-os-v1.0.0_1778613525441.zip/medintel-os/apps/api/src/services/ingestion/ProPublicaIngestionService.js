/**
 * ProPublica Nonprofit Explorer — FREE
 * IRS Form 990 data for all US nonprofit hospitals.
 * https://projects.propublica.org/nonprofits/api
 */
import db from '../../config/database.js';
import { logger } from '../../config/logger.js';

export class ProPublicaIngestionService {
  async fetch990ForFacility(ein, fiscalYear) {
    const resp = await fetch(
      `https://projects.propublica.org/nonprofits/api/v2/organizations/${ein}.json`
    );
    if (!resp.ok) return null;
    const data = await resp.json();

    const filings = data.filings_with_data || [];
    const filing = fiscalYear
      ? filings.find(f => f.tax_prd_yr === fiscalYear)
      : filings[0];

    if (!filing) return null;

    return {
      doc_type: '990',
      fiscal_year: filing.tax_prd_yr,
      total_revenue: filing.totrevenue,
      operating_income: filing.totfuncexpns ? filing.totrevenue - filing.totfuncexpns : null,
      capital_expenditures: filing.capex,
      long_term_debt: filing.totliabend,
      source_url: filing.pdf_url,
      raw_json: filing,
    };
  }

  async saveForFacility(facilityId, ein, fiscalYear) {
    const data = await this.fetch990ForFacility(ein, fiscalYear);
    if (!data) return null;

    await db('financial_documents')
      .insert({ facility_id: facilityId, ...data, ingested_at: new Date() })
      .onConflict(['facility_id', 'doc_type', 'fiscal_year'])
      .merge();

    return data;
  }
}
