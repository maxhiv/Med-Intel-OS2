/**
 * NPPES / CMS Ingestion Service — FREE
 * Ingests NPPES NPI Registry bulk data into the facilities + facility_contacts tables.
 * Source: https://download.cms.gov/nppes/NPI_Files.html
 *
 * Also integrates:
 * - CMS Provider of Services (POS) for hospital metadata
 * - CMS Care Compare for quality ratings
 * - CMS Medicare Provider Utilization for procedure volumes
 */
import db from '../../config/database.js';
import { logger } from '../../config/logger.js';

export class NPPESIngestionService {
  /**
   * Sync a single facility by NPI (real-time lookup)
   */
  async syncFacilityByNPI(npi) {
    const resp = await fetch(
      `https://npiregistry.cms.hhs.gov/api/?version=2.1&number=${npi}&pretty=true`
    );
    if (!resp.ok) throw new Error(`NPPES ${resp.status}`);
    const data = await resp.json();

    if (!data.results?.length) return null;

    const r = data.results[0];
    const addr = r.addresses?.find(a => a.address_purpose === 'LOCATION') || r.addresses?.[0];
    const basic = r.basic || {};

    const facilityData = {
      npi: r.number,
      name: basic.organization_name || `${basic.first_name || ''} ${basic.last_name || ''}`.trim(),
      facility_type: this._mapTaxonomyToType(r.taxonomies),
      address1: addr?.address_1,
      city: addr?.city,
      state: addr?.state,
      zip: addr?.postal_code?.substring(0, 5),
      updated_at: new Date(),
    };

    await db('facilities')
      .insert({ ...facilityData, last_scraped_at: new Date() })
      .onConflict('npi')
      .merge(facilityData);

    return facilityData;
  }

  /**
   * Bulk load HCRIS cost report data for a facility
   */
  async loadHCRISData(npi) {
    // HCRIS Form S-7 provides itemized equipment depreciation schedules
    // Download: https://www.cms.gov/Research-Statistics-Data-and-Systems/Downloadable-Public-Use-Files/Cost-Reports
    logger.debug(`Loading HCRIS data for NPI ${npi}`);
    // TODO: Implement HCRIS parser
  }

  /**
   * Fetch CMS procedure volume data (Medicare utilization)
   */
  async loadProcedureVolume(npi, year = 2023) {
    try {
      const resp = await fetch(
        `https://data.cms.gov/data-api/v1/dataset/physiciancompare/data?` +
        `npi=${npi}&limit=100`
      );
      if (!resp.ok) return null;
      const data = await resp.json();
      return data;
    } catch (err) {
      logger.warn(`CMS procedure volume for ${npi}: ${err.message}`);
      return null;
    }
  }

  async checkForUpdates() {
    logger.info('Checking for NPPES monthly update...');
    // NPPES publishes monthly bulk files — track last_modified header
    // to determine if a new file is available
  }

  _mapTaxonomyToType(taxonomies = []) {
    const codes = taxonomies.map(t => t.code || '');
    if (codes.some(c => c.startsWith('282N'))) return 'hospital';
    if (codes.some(c => c.startsWith('261Q'))) return 'asc';
    if (codes.some(c => c.startsWith('261QX'))) return 'imaging_center';
    if (codes.some(c => c.startsWith('251'))) return 'health_system';
    return 'medical_facility';
  }
}
