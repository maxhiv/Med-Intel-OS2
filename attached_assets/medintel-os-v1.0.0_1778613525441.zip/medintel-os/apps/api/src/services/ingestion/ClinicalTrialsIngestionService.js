/**
 * ClinicalTrials.gov Ingestion — FREE
 * REST API v2: https://clinicaltrials.gov/api/v2/studies
 * Finds trials at target facilities involving imaging/device interventions.
 */
import db from '../../config/database.js';
import { logger } from '../../config/logger.js';

const IMAGING_TERMS = ['MRI', 'CT scan', 'PET', 'ultrasound', 'X-ray', 'fluoroscopy',
  'nuclear medicine', 'mammography', 'radiation therapy', 'interventional radiology'];

export class ClinicalTrialsIngestionService {
  async fetchTrialsForFacility(facilityName, state) {
    const resp = await fetch(
      `https://clinicaltrials.gov/api/v2/studies?` + new URLSearchParams({
        'query.locn': `${facilityName}, ${state}`,
        'query.intr': IMAGING_TERMS.slice(0, 5).join(' OR '),
        'filter.overallStatus': 'RECRUITING,ACTIVE_NOT_RECRUITING',
        'fields': 'NCTId,BriefTitle,OverallStatus,StartDate,PrimaryCompletionDate,InterventionType',
        'pageSize': '10',
      })
    );

    if (!resp.ok) return [];
    const data = await resp.json();
    return (data.studies || []).map(s => ({
      nct_id: s.protocolSection?.identificationModule?.nctId,
      title: s.protocolSection?.identificationModule?.briefTitle,
      status: s.protocolSection?.statusModule?.overallStatus,
      start_date: s.protocolSection?.statusModule?.startDateStruct?.date,
      interventions: s.protocolSection?.armsInterventionsModule?.interventions?.map(i => i.interventionType) || [],
    }));
  }

  async updateFacilityResearch(facilityId, facilityName, state) {
    const trials = await this.fetchTrialsForFacility(facilityName, state);
    const imagingTrials = trials.filter(t =>
      t.interventions?.some(i => ['Device', 'Procedure', 'Radiation'].includes(i))
    );

    if (!imagingTrials.length) return;

    await db('facility_research')
      .insert({
        facility_id: facilityId,
        active_trials_count: trials.length,
        active_trials_imaging: JSON.stringify(imagingTrials),
        last_updated: new Date(),
      })
      .onConflict('facility_id')
      .merge({ active_trials_count: trials.length, active_trials_imaging: JSON.stringify(imagingTrials), last_updated: new Date() });

    // Create purchase signals for imaging trials
    if (imagingTrials.length > 0) {
      await db('purchase_signals').insert({
        facility_id: facilityId,
        signal_type: 'clinical_trial',
        signal_value: `${imagingTrials.length} active imaging trials — pre-funded equipment budget`,
        confidence: 85,
        source: 'clinicaltrials_gov',
      }).onConflict().ignore();
    }
  }
}
