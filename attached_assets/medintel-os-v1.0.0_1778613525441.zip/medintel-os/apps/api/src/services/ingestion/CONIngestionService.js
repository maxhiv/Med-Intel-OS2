/**
 * Certificate of Need (CON) Ingestion — FREE
 * 36 states require public disclosure before purchasing imaging equipment.
 * This is the highest-intent purchase signal available.
 *
 * State portals:
 * - AL: SHPDA - https://shpda.alabama.gov
 * - FL: AHCA - https://ahca.myflorida.com
 * - GA: COPN - https://dch.georgia.gov
 * - (add per state)
 */
import db from '../../config/database.js';
import { WebScraperService } from '../scraping/WebScraperService.js';
import { logger } from '../../config/logger.js';

const CON_STATES = ['AL', 'FL', 'GA', 'SC', 'NC', 'VA', 'MD', 'NY', 'MA', 'IL',
  'OH', 'MI', 'WI', 'MN', 'IA', 'MO', 'AR', 'LA', 'MS', 'TN', 'KY',
  'WV', 'HI', 'CT', 'VT', 'ME', 'NH', 'RI', 'NJ', 'DE', 'DC', 'OR', 'WA',
  'AK', 'MT', 'ND', 'SD'];

export class CONIngestionService {
  async scrapeNewFilings() {
    logger.info(`Scraping CON filings for ${CON_STATES.length} states`);
    for (const state of CON_STATES.slice(0, 5)) {  // Start with top 5 by volume
      await this._scrapeState(state).catch(err =>
        logger.warn(`CON scrape failed for ${state}: ${err.message}`)
      );
    }
  }

  async _scrapeState(state) {
    // Each state has a different portal — implement per-state scrapers
    // Alabama example:
    if (state === 'AL') {
      const scraper = new WebScraperService();
      const content = await scraper.fetchPage('https://shpda.alabama.gov/con-applications');
      // TODO: Parse Alabama CON applications
      logger.debug(`AL CON scrape: ${content?.length || 0} bytes`);
    }
  }
}
