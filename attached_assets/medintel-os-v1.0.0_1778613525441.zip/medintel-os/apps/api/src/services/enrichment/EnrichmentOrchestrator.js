/**
 * MedIntel OS — Enrichment Orchestrator
 *
 * POLICY: Free sources run automatically.
 *         Paid sources require explicit platform admin approval stored in
 *         enrichment_source_approvals table AND the corresponding *_ENABLED
 *         env var to be true. Two-gate system — both must pass.
 *
 * WATERFALL ORDER:
 *   1. NPI Registry          (FREE)
 *   2. Doximity              (FREE — clinicians only)
 *   3. Website scrape        (FREE)
 *   4. CMS Medicare billing  (FREE)
 *   5. Professional dirs     (FREE)
 *   6. Apollo.io             (PAID — approval required)
 *   7. Netrows (LinkedIn)    (PAID — approval required)
 *   8. ZeroBounce SMTP       (PAID — approval required)
 *   9. Bouncer catch-all     (PAID — approval required)
 *  10. Twilio phone          (PAID — approval required)
 *  11. People Data Labs      (PAID — approval required)
 *  12. Human review queue    (internal)
 */
import db from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/env.js';

// Free sources (always available)
import { NPISource } from './sources/NPISource.js';
import { DoximitySource } from './sources/DoximitySource.js';
import { WebsiteScrapeSource } from './sources/WebsiteScrapeSource.js';
import { CMSBillingSource } from './sources/CMSBillingSource.js';
import { ProfDirSource } from './sources/ProfDirSource.js';

// Paid sources (gated)
import { ApolloSource } from './sources/ApolloSource.js';
import { NetrowsSource } from './sources/NetrowsSource.js';
import { ZeroBounceSource } from './sources/ZeroBounceSource.js';
import { BouncerSource } from './sources/BouncerSource.js';
import { TwilioSource } from './sources/TwilioSource.js';
import { PDLSource } from './sources/PDLSource.js';

// ── Confidence scoring weights ────────────────────────────────────────────────
const CONFIDENCE_WEIGHTS = {
  smtp_valid:                   +30,
  smtp_catch_all:               -15,
  linkedin_employer_match:      +20,
  cms_billing_confirmed:        +18,
  doximity_verified:            +18,
  website_found:                +10,
  professional_dir_match:       +8,
  phone_valid_mobile:           +5,
  phone_valid_landline:         +3,
  only_one_source:              -20,
  linkedin_inactive_90d:        -10,
};

export class EnrichmentOrchestrator {
  constructor() {
    this._approvalCache = null;
    this._cacheExpiry = 0;
  }

  /**
   * Load approved paid sources from DB (cached for 5 min)
   */
  async getApprovedSources() {
    if (this._approvalCache && Date.now() < this._cacheExpiry) {
      return this._approvalCache;
    }
    const rows = await db('enrichment_source_approvals')
      .where('approved', true)
      .select('source', 'monthly_budget_limit', 'current_month_spend');
    this._approvalCache = new Set(rows.map(r => r.source));
    this._cacheExpiry = Date.now() + 5 * 60 * 1000;
    return this._approvalCache;
  }

  /**
   * Check if a paid source is approved (DB approval + env var both required)
   */
  async isSourceApproved(sourceName) {
    const envFlagMap = {
      apollo:           config.APOLLO_ENABLED,
      netrows:          config.NETROWS_ENABLED,
      zerobounce:       config.ZEROBOUNCE_ENABLED,
      bouncer:          config.BOUNCER_ENABLED,
      twilio:           config.TWILIO_ENABLED,
      people_data_labs: config.PDL_ENABLED,
      zoominfo:         config.ZOOMINFO_ENABLED,
      definitive_hc:    config.DEFINITIVE_HC_ENABLED,
    };

    const envEnabled = envFlagMap[sourceName] ?? false;
    if (!envEnabled) {
      logger.debug(`Source ${sourceName}: env flag disabled`);
      return false;
    }

    const approved = await this.getApprovedSources();
    const dbApproved = approved.has(sourceName);

    if (!dbApproved) {
      logger.debug(`Source ${sourceName}: not approved in DB — requires platform admin approval`);
    }

    return dbApproved;
  }

  /**
   * Run the full enrichment waterfall for a contact
   */
  async enrichContact(contactId, options = {}) {
    const { forceSources = [], dryRun = false } = options;

    const contact = await db('facility_contacts')
      .join('facilities', 'facilities.id', 'facility_contacts.facility_id')
      .where('facility_contacts.id', contactId)
      .select(
        'facility_contacts.*',
        'facilities.name as facility_name',
        'facilities.npi as facility_npi',
        'facilities.website as facility_website',
        'facilities.state as facility_state',
      )
      .first();

    if (!contact) throw new Error(`Contact ${contactId} not found`);

    logger.info(`Enriching contact: ${contact.full_name} @ ${contact.facility_name}`);

    const result = {
      contactId,
      sourcesRun: [],
      sourcesSkipped: [],
      changes: {},
      confidenceBefore: contact.confidence_score,
      confidenceAfter: contact.confidence_score,
    };

    let score = contact.confidence_score;
    let sourceCount = 0;

    // ── WATERFALL ──────────────────────────────────────────────────────────

    // Step 1: NPI Registry (FREE)
    const npiResult = await this._runSource('npi_registry', NPISource, contact, dryRun, result);
    if (npiResult?.npi) sourceCount++;

    // Step 2: Doximity (FREE — clinicians only)
    if (contact.npi || contact.title?.match(/MD|DO|NP|PA|RN|physician|doctor/i)) {
      await this._runSource('doximity', DoximitySource, contact, dryRun, result);
      if (result.changes.doximity_verified) { score += CONFIDENCE_WEIGHTS.doximity_verified; sourceCount++; }
    }

    // Step 3: Website scrape (FREE)
    if (contact.facility_website) {
      await this._runSource('website_scrape', WebsiteScrapeSource, contact, dryRun, result);
      if (result.changes.website_found) { score += CONFIDENCE_WEIGHTS.website_found; sourceCount++; }
    }

    // Step 4: CMS Medicare billing (FREE)
    await this._runSource('cms_billing', CMSBillingSource, contact, dryRun, result);
    if (result.changes.cms_billing_verified) { score += CONFIDENCE_WEIGHTS.cms_billing_confirmed; sourceCount++; }

    // Step 5: Professional directories (FREE)
    await this._runSource('professional_directory', ProfDirSource, contact, dryRun, result);
    if (result.changes.prof_dir_match) { score += CONFIDENCE_WEIGHTS.professional_dir_match; sourceCount++; }

    // ── PAID SOURCES (each requires approval) ─────────────────────────────

    // Step 6: Apollo.io email + contact (PAID)
    if (!contact.email || contact.email_status === 'unverified') {
      if (await this.isSourceApproved('apollo')) {
        await this._runSource('apollo', ApolloSource, contact, dryRun, result);
      } else {
        result.sourcesSkipped.push({ source: 'apollo', reason: 'awaiting_approval' });
      }
    }

    // Step 7: Netrows LinkedIn (PAID)
    if (!contact.linkedin_url || !contact.linkedin_data) {
      if (await this.isSourceApproved('netrows')) {
        const netrowsResult = await this._runSource('netrows', NetrowsSource, contact, dryRun, result);
        if (netrowsResult?.employer_match) { score += CONFIDENCE_WEIGHTS.linkedin_employer_match; sourceCount++; }
      } else {
        result.sourcesSkipped.push({ source: 'netrows', reason: 'awaiting_approval' });
      }
    }

    // Step 8: ZeroBounce SMTP verification (PAID)
    if (contact.email) {
      if (await this.isSourceApproved('zerobounce')) {
        const zbResult = await this._runSource('zerobounce', ZeroBounceSource, contact, dryRun, result);
        if (zbResult?.status === 'valid') score += CONFIDENCE_WEIGHTS.smtp_valid;
        if (zbResult?.status === 'catch_all') score += CONFIDENCE_WEIGHTS.smtp_catch_all;
      } else {
        result.sourcesSkipped.push({ source: 'zerobounce', reason: 'awaiting_approval' });
      }
    }

    // Step 9: Bouncer catch-all resolution (PAID)
    if (contact.email && result.changes.email_status === 'catch_all') {
      if (await this.isSourceApproved('bouncer')) {
        await this._runSource('bouncer', BouncerSource, contact, dryRun, result);
      } else {
        result.sourcesSkipped.push({ source: 'bouncer', reason: 'awaiting_approval' });
      }
    }

    // Step 10: Twilio phone validation (PAID)
    if (contact.phone) {
      if (await this.isSourceApproved('twilio')) {
        const twilioResult = await this._runSource('twilio', TwilioSource, contact, dryRun, result);
        if (twilioResult?.valid && twilioResult?.line_type === 'mobile') score += CONFIDENCE_WEIGHTS.phone_valid_mobile;
        if (twilioResult?.valid && twilioResult?.line_type === 'landline') score += CONFIDENCE_WEIGHTS.phone_valid_landline;
      } else {
        result.sourcesSkipped.push({ source: 'twilio', reason: 'awaiting_approval' });
      }
    }

    // Step 11: People Data Labs context (PAID)
    if (await this.isSourceApproved('people_data_labs')) {
      await this._runSource('people_data_labs', PDLSource, contact, dryRun, result);
    } else {
      result.sourcesSkipped.push({ source: 'people_data_labs', reason: 'awaiting_approval' });
    }

    // ── Score adjustments ─────────────────────────────────────────────────
    if (sourceCount === 1) score += CONFIDENCE_WEIGHTS.only_one_source;
    score = Math.max(0, Math.min(100, score));
    result.confidenceAfter = score;

    // ── Persist changes ───────────────────────────────────────────────────
    if (!dryRun && Object.keys(result.changes).length > 0) {
      await db('facility_contacts').where({ id: contactId }).update({
        ...result.changes,
        confidence_score: score,
        last_enriched_at: new Date(),
        enrichment_sources: db.raw(
          'array_cat(enrichment_sources, ?::enrichment_source[])',
          [result.sourcesRun]
        ),
        updated_at: new Date(),
      });

      // Enqueue for human review if high-value and fully validated
      if (score >= 80 && !contact.human_verified) {
        await this._enqueueHumanReview(contactId, score);
      }
    }

    logger.info(`Enrichment complete: ${contact.full_name} | score ${result.confidenceBefore} → ${score} | sources: ${result.sourcesRun.join(', ')}`);
    return result;
  }

  async _runSource(sourceName, SourceClass, contact, dryRun, result) {
    try {
      const source = new SourceClass();
      const data = await source.enrich(contact);

      if (data) {
        result.sourcesRun.push(sourceName);
        Object.assign(result.changes, data);

        // Log validation event
        if (!dryRun) {
          await db('contact_validation_log').insert({
            contact_id: contact.id,
            check_type: sourceName,
            result: data.validation_result || 'found',
            confidence_delta: data.confidence_delta || 0,
            raw_response: data.raw_response || null,
          });
        }

        delete data.validation_result;
        delete data.confidence_delta;
        delete data.raw_response;
      }

      return data;
    } catch (err) {
      logger.warn(`Source ${sourceName} failed for contact ${contact.id}: ${err.message}`);
      result.sourcesSkipped.push({ source: sourceName, reason: 'error', error: err.message });
      return null;
    }
  }

  async _enqueueHumanReview(contactId, score) {
    await db('contact_enrichment_queue')
      .insert({
        contact_id: contactId,
        priority: score >= 90 ? 9 : 7,
        trigger_reason: 'high_score_review',
        next_source: 'human_review',
        scheduled_at: new Date(),
      })
      .onConflict('contact_id')
      .ignore();
  }
}

export const enrichmentOrchestrator = new EnrichmentOrchestrator();
export default enrichmentOrchestrator;
