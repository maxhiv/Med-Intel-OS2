/**
 * Doximity Source — FREE (public profile scrape)
 * Verifies physician employment + specialty via public profile search.
 * NOT the Doximity API (requires partnership). Uses public search.
 */
import { WebScraperService } from '../../scraping/WebScraperService.js';

export class DoximitySource {
  async enrich(contact) {
    if (!contact.full_name) return null;

    const scraper = new WebScraperService();
    const query = `site:doximity.com "${contact.first_name} ${contact.last_name}" "${contact.facility_name}"`;

    try {
      const results = await scraper.googleSearch(query, 3);
      if (!results.length) return null;

      const doximityResult = results.find(r => r.url.includes('doximity.com/pub/'));
      if (!doximityResult) return null;

      return {
        doximity_verified: true,
        doximity_url: doximityResult.url,
        validation_result: 'verified',
        confidence_delta: 18,
        raw_response: { url: doximityResult.url, snippet: doximityResult.snippet },
      };
    } catch {
      return null;
    }
  }
}
