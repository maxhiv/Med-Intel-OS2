/**
 * Website Scrape Source — FREE
 * Uses Firecrawl/Crawl4AI to extract contacts from facility website.
 * Looks for staff directories, leadership pages, radiology department pages.
 */
import { WebScraperService } from '../../scraping/WebScraperService.js';

export class WebsiteScrapeSource {
  async enrich(contact) {
    if (!contact.facility_website) return null;

    const scraper = new WebScraperService();
    const targetPaths = ['/about', '/leadership', '/staff', '/radiology', '/team', '/physicians'];

    for (const path of targetPaths) {
      try {
        const url = `${contact.facility_website.replace(/\/$/, '')}${path}`;
        const content = await scraper.fetchPage(url);
        if (!content) continue;

        // Claude-powered structured extraction
        const extracted = await scraper.extractContactsWithClaude(content, contact.full_name);
        if (extracted?.email) {
          return {
            email: extracted.email,
            phone: extracted.phone || contact.phone,
            title: extracted.title || contact.title,
            website_found: true,
            validation_result: 'found',
            confidence_delta: 10,
            raw_response: { url, extracted },
          };
        }
      } catch {
        continue;
      }
    }

    return null;
  }
}
