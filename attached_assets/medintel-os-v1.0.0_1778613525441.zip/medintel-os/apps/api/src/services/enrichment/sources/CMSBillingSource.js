/**
 * CMS Medicare Billing Cross-Reference — FREE
 * Confirms a clinician is actively billing from a specific NPI + facility.
 * Uses CMS Medicare Provider Utilization & Payment Data.
 */
export class CMSBillingSource {
  async enrich(contact) {
    if (!contact.npi) return null;

    try {
      const resp = await fetch(
        `https://data.cms.gov/data-api/v1/dataset/physicianscompare/data?` +
        new URLSearchParams({ npi: contact.npi, size: 1 })
      );
      if (!resp.ok) return null;
      const data = await resp.json();

      if (!data.data?.length) return null;

      const record = data.data[0];
      return {
        cms_billing_verified: true,
        title: contact.title || record.pri_spec,
        validation_result: 'verified',
        confidence_delta: 18,
        raw_response: { npi: contact.npi, specialty: record.pri_spec },
      };
    } catch {
      return null;
    }
  }
}
