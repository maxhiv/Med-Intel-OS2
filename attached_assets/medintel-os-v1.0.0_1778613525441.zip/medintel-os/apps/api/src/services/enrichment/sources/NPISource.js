/**
 * NPI Registry Source — FREE
 * NPPES NPI Lookup API: https://npiregistry.cms.hhs.gov/api/
 * Returns provider identity, taxonomy, practice address, license state.
 */
export class NPISource {
  async enrich(contact) {
    if (!contact.npi && !contact.full_name) return null;

    const params = new URLSearchParams({
      version: '2.1',
      pretty: 'true',
      limit: 5,
      ...(contact.npi ? { number: contact.npi } : {
        first_name: contact.first_name,
        last_name: contact.last_name,
        state: contact.facility_state,
      }),
    });

    const resp = await fetch(`https://npiregistry.cms.hhs.gov/api/?${params}`);
    if (!resp.ok) throw new Error(`NPPES API ${resp.status}`);
    const data = await resp.json();

    if (!data.results?.length) return null;

    const result = data.results[0];
    const basic = result.basic || {};

    return {
      npi: result.number,
      first_name: basic.first_name || contact.first_name,
      last_name: basic.last_name || contact.last_name,
      validation_result: 'found',
      confidence_delta: 5,
      raw_response: { npi: result.number, taxonomy: result.taxonomies?.[0]?.desc },
    };
  }
}
