/**
 * Web Scraper Service
 * Uses Firecrawl (or Crawl4AI) for JS-rendered pages.
 * Uses Claude for structured data extraction from scraped content.
 */
import { claudeService } from '../ai/ClaudeService.js';
import { config } from '../../config/env.js';
import { logger } from '../../config/logger.js';

export class WebScraperService {
  async fetchPage(url, options = {}) {
    try {
      if (config.FIRECRAWL_API_KEY) {
        return this._fetchWithFirecrawl(url);
      }
      // Fallback: raw fetch (works for non-JS pages)
      const resp = await fetch(url, {
        headers: { 'User-Agent': 'MedIntelOS/1.0 (healthcare research; contact@hansenholdingsllc.com)' },
        signal: AbortSignal.timeout(15000),
      });
      if (!resp.ok) return null;
      return resp.text();
    } catch (err) {
      logger.debug(`fetchPage failed for ${url}: ${err.message}`);
      return null;
    }
  }

  async _fetchWithFirecrawl(url) {
    const resp = await fetch('https://api.firecrawl.dev/v0/scrape', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${config.FIRECRAWL_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url, formats: ['markdown'] }),
    });

    if (!resp.ok) throw new Error(`Firecrawl ${resp.status}`);
    const data = await resp.json();
    return data.data?.markdown || data.data?.content || null;
  }

  async extractContactsWithClaude(pageContent, targetName = null) {
    const contacts = await claudeService.extractContactsFromPage(pageContent, targetName);
    if (!contacts?.length) return null;
    // Return the best match if we were looking for someone specific
    if (targetName) {
      return contacts.find(c =>
        c.name?.toLowerCase().includes(targetName?.split(' ')[1]?.toLowerCase() || '')
      ) || contacts[0];
    }
    return contacts[0];
  }

  async googleSearch(query, maxResults = 5) {
    // Uses DuckDuckGo HTML (no API key required for basic search)
    try {
      const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
      const html = await this.fetchPage(url);
      if (!html) return [];

      // Parse basic results (simplified)
      const results = [];
      const regex = /class="result__url"[^>]*>([^<]+)<\/a>[\s\S]*?class="result__snippet"[^>]*>([^<]+)</g;
      let match;
      while ((match = regex.exec(html)) !== null && results.length < maxResults) {
        results.push({ url: match[1].trim(), snippet: match[2].trim() });
      }
      return results;
    } catch {
      return [];
    }
  }
}
