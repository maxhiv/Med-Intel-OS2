/**
 * GoHighLevel (GHL) CRM Adapter
 * Uses existing GHL MCP + REST API.
 * GHL is the primary platform (LeadStack existing infra).
 */
import { CRMAdapter } from './CRMAdapter.js';
import { config } from '../../config/env.js';
import { logger } from '../../config/logger.js';

export class GHLAdapter extends CRMAdapter {
  constructor(credentials = {}) {
    super(credentials);
    this.apiKey = credentials.api_key || config.GHL_API_KEY;
    this.locationId = credentials.location_id || config.GHL_LOCATION_ID;
    this.base = config.GHL_API_BASE;
  }

  async _request(method, path, body = null) {
    const resp = await fetch(`${this.base}${path}`, {
      method,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'Version': '2021-07-28',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!resp.ok) {
      const err = await resp.text();
      throw new Error(`GHL API ${resp.status}: ${err}`);
    }

    return resp.json();
  }

  async pushContact(contact, facility) {
    const payload = {
      firstName: contact.first_name,
      lastName: contact.last_name,
      email: contact.email,
      phone: contact.phone,
      companyName: facility.name,
      address1: facility.address1,
      city: facility.city,
      state: facility.state,
      postalCode: facility.zip,
      tags: [`medintel`, `facility:${facility.npi}`, `score:${contact.buying_authority_score}`],
      customField: {
        npi: contact.npi || '',
        title: contact.title || '',
        confidence_score: String(contact.confidence_score),
        facility_npi: facility.npi,
        signal_score: String(facility.signal_score),
      },
      locationId: this.locationId,
    };

    const result = await this._request('POST', '/contacts/', payload);
    return result.contact?.id;
  }

  async pushCompany(facility) {
    // GHL doesn't have a native company object — map to opportunity/pipeline
    return facility.id;
  }

  async pushDeal(contact, facility, campaignContact) {
    const result = await this._request('POST', '/opportunities/', {
      pipelineId: this.credentials.pipeline_id,
      name: `${facility.name} — ${contact.title || 'Contact'}`,
      contactId: campaignContact.crm_contact_id,
      status: 'open',
      monetaryValue: 0,
      locationId: this.locationId,
    });
    return result.opportunity?.id;
  }

  async saveEmailDraft(crmContactId, draft) {
    // Save as a note with [DRAFT] prefix — rep sees it in activity feed
    await this._request('POST', '/conversations/messages/', {
      type: 'Email',
      contactId: crmContactId,
      html: `<p><strong>[DRAFT - REVIEW BEFORE SENDING]</strong></p>${draft.body}`,
      subject: draft.subject,
      locationId: this.locationId,
    });
  }

  async logLinkedInNote(crmContactId, draft) {
    await this._request('POST', '/conversations/messages/', {
      type: 'Activity',
      contactId: crmContactId,
      body: `LinkedIn Draft:\n\n${draft.linkedin_message || draft.linkedin_note}`,
      locationId: this.locationId,
    });
  }

  async attachFile(crmContactId, filePath, fileName) {
    // TODO: Upload to GHL media, attach to contact note
    logger.debug(`GHL attachFile: ${fileName} to contact ${crmContactId}`);
  }

  async enrollSequence(crmContactId, sequenceName) {
    // GHL sequences via workflow trigger
    logger.debug(`GHL enrollSequence: ${sequenceName} for ${crmContactId}`);
  }
}
