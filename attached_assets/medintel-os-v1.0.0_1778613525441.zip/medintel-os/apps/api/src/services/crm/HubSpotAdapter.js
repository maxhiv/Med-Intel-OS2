/**
 * HubSpot CRM Adapter
 * Uses HubSpot API v3 with Private App token (scoped bearer, no expiry).
 * Sequences require Sales Hub Starter ($20+/mo) — falls back to draft engagement if unavailable.
 */
import { CRMAdapter } from './CRMAdapter.js';
import { logger } from '../../config/logger.js';

const HS_BASE = 'https://api.hubapi.com';

export class HubSpotAdapter extends CRMAdapter {
  constructor(credentials = {}) {
    super(credentials);
    this.token = credentials.access_token;
    if (!this.token) throw new Error('HubSpot requires access_token in credentials');
  }

  async _request(method, path, body = null) {
    const resp = await fetch(`${HS_BASE}${path}`, {
      method,
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!resp.ok) {
      const err = await resp.text();
      throw new Error(`HubSpot API ${resp.status}: ${err}`);
    }

    return resp.status === 204 ? null : resp.json();
  }

  async pushContact(contact, facility) {
    const payload = {
      properties: {
        firstname: contact.first_name,
        lastname: contact.last_name,
        email: contact.email,
        phone: contact.phone,
        jobtitle: contact.title,
        company: facility.name,
        city: facility.city,
        state: facility.state,
        zip: facility.zip,
        // Custom MedIntel properties (create these in HubSpot first)
        medintel_confidence_score: String(contact.confidence_score),
        medintel_facility_npi: facility.npi,
        medintel_signal_score: String(facility.signal_score),
        medintel_buying_authority: String(contact.buying_authority_score),
        linkedin_url: contact.linkedin_url,
      },
    };

    const result = await this._request('POST', '/crm/v3/objects/contacts', payload);
    return result.id;
  }

  async pushCompany(facility) {
    const payload = {
      properties: {
        name: facility.name,
        domain: facility.website?.replace(/https?:\/\/(www\.)?/, '').split('/')[0],
        city: facility.city,
        state: facility.state,
        zip: facility.zip,
        type: 'PROSPECT',
        medintel_npi: facility.npi,
        medintel_facility_type: facility.facility_type,
        medintel_signal_score: String(facility.signal_score),
        medintel_beds: String(facility.beds || ''),
      },
    };

    const result = await this._request('POST', '/crm/v3/objects/companies', payload);
    return result.id;
  }

  async pushDeal(contact, facility, campaignContact) {
    const result = await this._request('POST', '/crm/v3/objects/deals', {
      properties: {
        dealname: `${facility.name} — Imaging Equipment`,
        dealstage: 'appointmentscheduled',
        pipeline: 'default',
        amount: '0',
      },
    });
    return result.id;
  }

  async saveEmailDraft(crmContactId, draft) {
    // HubSpot: save as email engagement on the contact timeline
    await this._request('POST', '/crm/v3/objects/emails', {
      properties: {
        hs_timestamp: String(Date.now()),
        hubspot_owner_id: this.credentials.owner_id || '',
        hs_email_direction: 'EMAIL',
        hs_email_status: 'DRAFT',
        hs_email_subject: draft.subject,
        hs_email_text: draft.body,
        hs_email_html: draft.body,
      },
      associations: [{
        to: { id: crmContactId },
        types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 198 }],
      }],
    });
  }

  async logLinkedInNote(crmContactId, draft) {
    await this._request('POST', '/crm/v3/objects/notes', {
      properties: {
        hs_timestamp: String(Date.now()),
        hs_note_body: `**LinkedIn Draft**\n\n${draft.linkedin_message || draft.linkedin_note}`,
      },
      associations: [{
        to: { id: crmContactId },
        types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 202 }],
      }],
    });
  }

  async attachFile(crmContactId, filePath, fileName) {
    logger.debug(`HubSpot attachFile: ${fileName} to contact ${crmContactId}`);
    // TODO: Upload to HubSpot Files API, attach to contact engagement
  }

  async enrollSequence(crmContactId, sequenceName) {
    // Requires Sales Hub Starter + sequence enrollment API
    logger.debug(`HubSpot enrollSequence: ${sequenceName} for ${crmContactId}`);
  }
}
