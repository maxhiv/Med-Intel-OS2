/**
 * CRM Adapter — Abstract Base Class
 *
 * All CRM adapters (GHL, HubSpot, Salesforce, Pipedrive, etc.) implement
 * this interface. The batch processor calls this interface; it never cares
 * which CRM is on the other end.
 *
 * Sub-account CRM type and credentials are loaded from the sub_accounts table.
 * The factory (getCRMAdapter) instantiates the correct adapter.
 */

export class CRMAdapter {
  constructor(credentials) {
    if (new.target === CRMAdapter) {
      throw new Error('CRMAdapter is abstract — use a concrete implementation');
    }
    this.credentials = credentials;
  }

  /** Create or update a contact. Returns crm_contact_id */
  async pushContact(contact, facility) { throw new Error('Not implemented'); }

  /** Create or update a company/account record. Returns crm_company_id */
  async pushCompany(facility) { throw new Error('Not implemented'); }

  /** Create or update a deal/opportunity. Returns crm_deal_id */
  async pushDeal(contact, facility, campaignContact) { throw new Error('Not implemented'); }

  /**
   * Save an email draft to the contact's activity timeline.
   * The draft is NOT sent — it appears as a pending draft for the rep to review and click send.
   */
  async saveEmailDraft(crmContactId, draft) { throw new Error('Not implemented'); }

  /** Log a LinkedIn draft as a note on the contact record */
  async logLinkedInNote(crmContactId, draft) { throw new Error('Not implemented'); }

  /** Attach a file (report PDF) to a contact record */
  async attachFile(crmContactId, filePath, fileName) { throw new Error('Not implemented'); }

  /** Enroll contact in a CRM sequence (if supported by CRM tier) */
  async enrollSequence(crmContactId, sequenceName) { throw new Error('Not implemented'); }
}

/**
 * Factory — returns the correct adapter based on crm_type
 */
export async function getCRMAdapter(subAccount) {
  const { crm_type, crm_credentials } = subAccount;

  const { GHLAdapter } = await import('./GHLAdapter.js');
  const { HubSpotAdapter } = await import('./HubSpotAdapter.js');
  const { ApideckAdapter } = await import('./ApideckAdapter.js');

  switch (crm_type) {
    case 'ghl':
      return new GHLAdapter(crm_credentials);
    case 'hubspot':
      return new HubSpotAdapter(crm_credentials);
    case 'salesforce':
    case 'pipedrive':
    case 'zoho':
    case 'close':
    case 'dynamics':
      // Route through Apideck unified API for non-primary CRMs
      return new ApideckAdapter(crm_credentials, crm_type);
    default:
      throw new Error(`Unsupported CRM type: ${crm_type}`);
  }
}
