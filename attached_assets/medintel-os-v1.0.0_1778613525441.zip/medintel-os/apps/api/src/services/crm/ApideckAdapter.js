/**
 * Apideck Unified CRM Adapter
 * Routes to 200+ CRMs (Salesforce, Pipedrive, Zoho, Close, Dynamics, etc.)
 * via a single normalized API. Real-time, no data caching.
 *
 * Supports: GHL, HubSpot, Salesforce, Pipedrive, Zoho, Close, Freshsales,
 *           Microsoft Dynamics, Copper, Attio, and 190+ others.
 *
 * When to use: For any CRM that isn't GHL or HubSpot (primary adapters).
 * Apideck plan at $599/mo covers 25 client sub-accounts.
 */
import { CRMAdapter } from './CRMAdapter.js';
import { config } from '../../config/env.js';
import { logger } from '../../config/logger.js';

export class ApideckAdapter extends CRMAdapter {
  constructor(credentials, serviceId) {
    super(credentials);
    this.apiKey = config.APIDECK_API_KEY;
    this.appId = config.APIDECK_APP_ID;
    this.serviceId = serviceId;          // 'salesforce', 'pipedrive', 'zoho', etc.
    this.consumerId = credentials.consumer_id; // per-client Apideck consumer ID
  }

  async _request(method, path, body = null) {
    if (!this.apiKey || !config.APIDECK_ENABLED) {
      throw new Error('Apideck not configured. Set APIDECK_API_KEY and APIDECK_ENABLED=true');
    }

    const resp = await fetch(`https://unify.apideck.com${path}`, {
      method,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'x-apideck-app-id': this.appId,
        'x-apideck-consumer-id': this.consumerId,
        'x-apideck-service-id': this.serviceId,
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!resp.ok) {
      const err = await resp.text();
      throw new Error(`Apideck [${this.serviceId}] ${resp.status}: ${err}`);
    }

    return resp.json();
  }

  async pushContact(contact, facility) {
    const result = await this._request('POST', '/crm/contacts', {
      first_name: contact.first_name,
      last_name: contact.last_name,
      email_addresses: contact.email ? [{ email: contact.email, type: 'work' }] : [],
      phone_numbers: contact.phone ? [{ number: contact.phone, type: 'work' }] : [],
      job_title: contact.title,
      company_name: facility.name,
    });
    return result.data?.id;
  }

  async pushCompany(facility) {
    const result = await this._request('POST', '/crm/companies', {
      name: facility.name,
      address: { city: facility.city, state: facility.state, zip: facility.zip },
    });
    return result.data?.id;
  }

  async pushDeal(contact, facility, campaignContact) {
    const result = await this._request('POST', '/crm/opportunities', {
      title: `${facility.name} — Imaging Equipment`,
      status: 'Open',
    });
    return result.data?.id;
  }

  async saveEmailDraft(crmContactId, draft) {
    await this._request('POST', '/crm/activities', {
      type: 'email',
      subject: draft.subject,
      description: draft.body,
      contact_ids: [crmContactId],
    });
  }

  async logLinkedInNote(crmContactId, draft) {
    await this._request('POST', '/crm/notes', {
      content: `LinkedIn Draft:\n\n${draft.linkedin_message || draft.linkedin_note}`,
      contact_id: crmContactId,
    });
  }

  async attachFile(crmContactId, filePath, fileName) {
    logger.debug(`Apideck[${this.serviceId}] attachFile: ${fileName}`);
  }

  async enrollSequence(crmContactId, sequenceName) {
    logger.debug(`Apideck[${this.serviceId}] enrollSequence: ${sequenceName}`);
  }
}
