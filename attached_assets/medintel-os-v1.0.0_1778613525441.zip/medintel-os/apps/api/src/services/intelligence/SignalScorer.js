/**
 * Signal Scorer — recomputes composite purchase-signal scores for all facilities
 * Runs nightly via scheduler. Score drives sort order in facility lists.
 *
 * SCORING WEIGHTS (max 100):
 *   Equipment depreciation >80%    +30
 *   CON filed/approved              +25
 *   NIH grant for imaging           +20
 *   Clinical trial active           +15
 *   Capital bond issuance           +20
 *   Construction permit             +15
 *   Leadership change (CIO/CMO)     +15
 *   Job posting (radiology dir)     +12
 *   ACR renewal within 12mo         +10
 *   EHR go-live within 18mo         +8
 *   CMS compliance citation         +10
 */
import db from '../../config/database.js';
import { logger } from '../../config/logger.js';

const SIGNAL_WEIGHTS = {
  depreciation_flag:      30,
  con_filed:              20,
  con_approved:           25,
  nih_grant:              20,
  clinical_trial:         15,
  bond_issuance:          20,
  construction_permit:    15,
  leadership_change:      15,
  job_posting:            12,
  accreditation_renewal:  10,
  service_line_expansion: 10,
  eol_equipment:          18,
  fiscal_year_end:        8,
  compliance_citation:    10,
  news_expansion:         6,
};

export async function recomputeSignalScores(batchSize = 500) {
  logger.info('Recomputing facility signal scores...');
  let updated = 0;
  let cursor = null;

  do {
    const query = db('facilities').select('id').orderBy('id').limit(batchSize);
    if (cursor) query.where('id', '>', cursor);
    const facilities = await query;
    if (!facilities.length) break;

    for (const { id } of facilities) {
      const signals = await db('purchase_signals')
        .where({ facility_id: id, is_active: true })
        .select('signal_type', 'confidence');

      // Also check equipment depreciation directly
      const criticalEquip = await db('equipment_records')
        .where({ facility_id: id })
        .where('pct_depreciated', '>=', 80)
        .count('* as cnt')
        .first();

      let score = 0;
      const seen = new Set();

      for (const s of signals) {
        const weight = SIGNAL_WEIGHTS[s.signal_type] || 5;
        const key = s.signal_type;
        if (!seen.has(key)) {
          score += weight * (s.confidence / 100);
          seen.add(key);
        }
      }

      if (parseInt(criticalEquip.cnt) > 0) {
        score += SIGNAL_WEIGHTS.depreciation_flag * Math.min(parseInt(criticalEquip.cnt) / 3, 1);
      }

      score = Math.min(100, Math.round(score));

      await db('facilities').where({ id }).update({ signal_score: score });
      updated++;
    }

    cursor = facilities[facilities.length - 1].id;
  } while (true);

  logger.info(`Signal scores updated for ${updated} facilities`);
  return updated;
}
