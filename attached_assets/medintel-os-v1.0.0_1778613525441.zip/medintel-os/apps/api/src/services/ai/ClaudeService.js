/**
 * Claude AI Service
 * Handles all AI operations: sequence drafting, signal analysis,
 * contact extraction, reply classification, report generation.
 */
import Anthropic from '@anthropic-ai/sdk';
import { config } from '../../config/env.js';
import { logger } from '../../config/logger.js';

const client = new Anthropic({ apiKey: config.ANTHROPIC_API_KEY });

export class ClaudeService {
  /**
   * Generate a personalized outreach email draft
   * Uses all available facility + contact + signal intelligence
   */
  async generateEmailDraft({ contact, facility, step, signals, financials, equipment }) {
    const systemPrompt = `You are a B2B medical equipment sales intelligence assistant for MedIntel OS. 
You generate personalized, professional cold email drafts for medical device sales representatives.
Your emails are specific, data-driven, and reference real facility intelligence.
NEVER be generic. ALWAYS reference specific signals, equipment data, or financial insights.
Keep emails under 200 words. Use a consultative, peer-to-peer tone — never pushy.`;

    const userPrompt = `Generate email step ${step.step_num} of a ${step.sequence_id} sequence.

CONTACT:
- Name: ${contact.first_name} ${contact.last_name}
- Title: ${contact.title}
- Facility: ${facility.name} (${facility.city}, ${facility.state})
- Facility Type: ${facility.facility_type}

PURCHASE SIGNALS (use the most compelling 1-2):
${signals.map(s => `- ${s.signal_type}: ${s.signal_value}`).join('\n')}

EQUIPMENT INTELLIGENCE:
${equipment.map(e => `- ${e.modality}: ${e.manufacturer || 'Unknown'} ${e.model || ''}, ${e.pct_depreciated || 0}% depreciated, installed ${e.install_year || 'unknown'}`).join('\n')}

FINANCIAL CONTEXT:
${financials ? `- Revenue: $${(financials.total_revenue / 1e6).toFixed(1)}M | Operating margin: ${financials.operating_margin_pct || 'N/A'}%` : '- Financial data not available'}

EMAIL STEP INSTRUCTIONS: ${step.body_template}
SUBJECT TEMPLATE: ${step.subject_line}

Return ONLY a JSON object with fields: subject, body (HTML-safe text, no HTML tags)`;

    const response = await client.messages.create({
      model: config.ANTHROPIC_MODEL,
      max_tokens: 1000,
      messages: [{ role: 'user', content: userPrompt }],
      system: systemPrompt,
    });

    const text = response.content[0].text;
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  }

  /**
   * Generate a LinkedIn outreach message
   */
  async generateLinkedInDraft({ contact, facility, signals, messageType = 'connection_note' }) {
    const maxChars = messageType === 'connection_note' ? 300 : 600;

    const prompt = `Generate a LinkedIn ${messageType} for a medical device sales rep.

Contact: ${contact.first_name} ${contact.last_name}, ${contact.title} at ${facility.name}
Top signal: ${signals[0]?.signal_value || 'aging imaging equipment'}

Rules:
- Max ${maxChars} characters
- Peer-to-peer tone, not salesy
- Reference ONE specific detail about their facility
- Soft CTA only
- No "I noticed your profile" openings

Return ONLY JSON: { "message": "..." }`;

    const response = await client.messages.create({
      model: config.ANTHROPIC_MODEL,
      max_tokens: 200,
      messages: [{ role: 'user', content: prompt }],
    });

    const clean = response.content[0].text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  }

  /**
   * Extract structured contacts from scraped website HTML
   */
  async extractContactsFromPage(pageContent, targetName = null) {
    const prompt = `Extract contact information from this healthcare facility webpage content.

${targetName ? `Looking for: ${targetName}` : 'Extract all staff/leadership contacts found.'}

Content:
${pageContent.substring(0, 8000)}

Return ONLY a JSON array of objects with fields:
[{ "name", "title", "department", "email", "phone", "linkedin_url" }]
Return [] if none found.`;

    const response = await client.messages.create({
      model: config.ANTHROPIC_MODEL,
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    });

    const clean = response.content[0].text.replace(/```json|```/g, '').trim();
    try {
      return JSON.parse(clean);
    } catch {
      return [];
    }
  }

  /**
   * Classify a reply from a prospect
   */
  async classifyReply(replyText) {
    const prompt = `Classify this medical device sales prospect reply into ONE category:
- interested: positive response, wants to learn more or schedule
- not_now: not interested at this time but polite
- unsubscribe: wants to be removed
- wrong_person: not the right contact
- out_of_office: auto-reply

Reply: "${replyText}"

Return ONLY JSON: { "classification": "...", "confidence": 0.0-1.0, "summary": "1 sentence" }`;

    const response = await client.messages.create({
      model: config.ANTHROPIC_MODEL,
      max_tokens: 200,
      messages: [{ role: 'user', content: prompt }],
    });

    const clean = response.content[0].text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  }

  /**
   * Generate weekly intelligence digest for an account
   */
  async generateWeeklyDigest({ account, newSignals, newCONFilings, newNews }) {
    const prompt = `Generate a concise weekly intelligence digest for a medical device sales team.

New purchase signals this week (${newSignals.length} facilities):
${newSignals.slice(0, 10).map(s => `- ${s.facility_name}: ${s.signal_type} — ${s.signal_value}`).join('\n')}

New CON filings (${newCONFilings.length}):
${newCONFilings.slice(0, 5).map(c => `- ${c.applicant_name}: ${c.equipment_type} in ${c.state}`).join('\n')}

Return ONLY JSON: { "subject": "...", "summary": "3-4 sentences", "top_actions": ["...", "...", "..."] }`;

    const response = await client.messages.create({
      model: config.ANTHROPIC_MODEL,
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }],
    });

    const clean = response.content[0].text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  }
}

export const claudeService = new ClaudeService();
export default claudeService;
