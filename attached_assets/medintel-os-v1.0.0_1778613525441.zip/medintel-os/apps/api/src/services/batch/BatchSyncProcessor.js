/**
 * MedIntel OS — Batch Sync Processor
 *
 * CORE RULE: No email is EVER automatically sent.
 * All outreach drafts are pushed to the client's CRM as PENDING DRAFTS.
 * The rep reviews them in GHL/HubSpot/etc. and clicks Send themselves.
 *
 * Process:
 * 1. Package N approved drafts per sub-account (configurable batch size)
 * 2. Push contact records to CRM (create/update)
 * 3. Save email draft to contact timeline in CRM
 * 4. Log LinkedIn note on contact record
 * 5. Attach any relevant report PDFs
 * 6. Update sync_batches + sync_items tables
 * 7. Client sees enriched contact + pending email draft next morning
 */
import db from '../../config/database.js';
import { getCRMAdapter } from '../crm/CRMAdapter.js';
import { withRLS } from '../../middleware/auth.js';
import { logger } from '../../config/logger.js';

export class BatchSyncProcessor {
  /**
   * Run the daily batch for all active sub-accounts
   */
  async runDailyBatches() {
    logger.info('🔄 Starting daily batch sync...');

    const subAccounts = await db('sub_accounts')
      .join('accounts', 'accounts.id', 'sub_accounts.account_id')
      .where({
        'sub_accounts.is_active': true,
        'accounts.status': 'active',
      })
      .select('sub_accounts.*', 'accounts.name as account_name');

    let totalPushed = 0;
    let totalFailed = 0;

    for (const subAccount of subAccounts) {
      try {
        const result = await this.runBatchForSubAccount(subAccount);
        totalPushed += result.pushed;
        totalFailed += result.failed;
      } catch (err) {
        logger.error(`Batch failed for sub-account ${subAccount.id}: ${err.message}`);
        totalFailed++;
      }
    }

    logger.info(`✅ Daily batch complete. Pushed: ${totalPushed}, Failed: ${totalFailed}`);
    return { totalPushed, totalFailed };
  }

  async runBatchForSubAccount(subAccount) {
    const batchDate = new Date().toISOString().split('T')[0];

    // Check if batch already ran today
    const existing = await db('sync_batches')
      .where({ sub_account_id: subAccount.id, batch_date: batchDate })
      .first();
    if (existing?.status === 'complete') {
      logger.debug(`Batch already complete for sub-account ${subAccount.id} on ${batchDate}`);
      return { pushed: 0, failed: 0 };
    }

    // Create batch record
    const [batch] = await db('sync_batches').insert({
      account_id: subAccount.account_id,
      sub_account_id: subAccount.id,
      crm_type: subAccount.crm_type || 'ghl',
      batch_date: batchDate,
      status: 'running',
      started_at: new Date(),
    }).returning('*');

    try {
      // Get approved pending drafts for this sub-account
      const drafts = await withRLS(subAccount.account_id, (trx) =>
        trx('outreach_drafts')
          .join('contact_enrollments', 'contact_enrollments.id', 'outreach_drafts.enrollment_id')
          .join('campaign_contacts', 'campaign_contacts.id', 'contact_enrollments.campaign_contact_id')
          .join('campaigns', 'campaigns.id', 'campaign_contacts.campaign_id')
          .join('facility_contacts', 'facility_contacts.id', 'outreach_drafts.contact_id')
          .join('facilities', 'facilities.id', 'outreach_drafts.facility_id')
          .where({
            'campaigns.sub_account_id': subAccount.id,
            'outreach_drafts.status': 'approved',
            'outreach_drafts.crm_synced_at': null,
          })
          .limit(subAccount.batch_size_daily || 10)
          .select(
            'outreach_drafts.*',
            'facility_contacts.first_name', 'facility_contacts.last_name',
            'facility_contacts.email', 'facility_contacts.phone',
            'facility_contacts.title', 'facility_contacts.linkedin_url',
            'facility_contacts.confidence_score', 'facility_contacts.buying_authority_score',
            'facility_contacts.npi',
            'facilities.name as facility_name', 'facilities.npi as facility_npi',
            'facilities.address1', 'facilities.city', 'facilities.state', 'facilities.zip',
            'facilities.signal_score', 'facilities.website as facility_website',
          )
      );

      await db('sync_batches').where({ id: batch.id }).update({ target_count: drafts.length });

      if (!drafts.length) {
        await db('sync_batches').where({ id: batch.id }).update({ status: 'complete', completed_at: new Date() });
        return { pushed: 0, failed: 0 };
      }

      // Get CRM adapter for this sub-account
      const crmAdapter = await getCRMAdapter(subAccount);

      let pushed = 0;
      let failed = 0;

      for (const draft of drafts) {
        const contact = {
          id: draft.contact_id,
          first_name: draft.first_name,
          last_name: draft.last_name,
          email: draft.email,
          phone: draft.phone,
          title: draft.title,
          linkedin_url: draft.linkedin_url,
          confidence_score: draft.confidence_score,
          buying_authority_score: draft.buying_authority_score,
          npi: draft.npi,
        };

        const facility = {
          id: draft.facility_id,
          name: draft.facility_name,
          npi: draft.facility_npi,
          address1: draft.address1,
          city: draft.city,
          state: draft.state,
          zip: draft.zip,
          signal_score: draft.signal_score,
          website: draft.facility_website,
        };

        try {
          // 1. Push/update contact in CRM
          let crmContactId = await this._getExistingCRMContactId(subAccount, draft.contact_id);

          if (!crmContactId) {
            // Push company first
            const crmCompanyId = await crmAdapter.pushCompany(facility);

            // Then push contact
            crmContactId = await crmAdapter.pushContact(contact, facility);

            // Create deal
            const crmDealId = await crmAdapter.pushDeal(contact, facility, draft);

            // Record mapping
            await db('crm_contacts_map').insert({
              account_id: subAccount.account_id,
              local_contact_id: draft.contact_id,
              crm_type: subAccount.crm_type || 'ghl',
              crm_contact_id: crmContactId,
              crm_company_id: crmCompanyId,
              crm_deal_id: crmDealId,
            }).onConflict(['account_id', 'local_contact_id', 'crm_type']).merge();
          }

          // 2. Save email draft to CRM timeline (NOT sent — pending for rep)
          await crmAdapter.saveEmailDraft(crmContactId, draft);

          // 3. Log LinkedIn draft as note (if present)
          if (draft.linkedin_message || draft.linkedin_note) {
            await crmAdapter.logLinkedInNote(crmContactId, draft);
          }

          // 4. Mark draft as synced
          await db('outreach_drafts').where({ id: draft.id }).update({
            status: 'sent',           // 'sent' means pushed to CRM, not emailed
            crm_draft_id: crmContactId,
            crm_synced_at: new Date(),
          });

          // 5. Log sync item
          await db('sync_items').insert({
            batch_id: batch.id,
            account_id: subAccount.account_id,
            entity_type: 'draft',
            local_id: draft.id,
            crm_id: crmContactId,
            crm_type: subAccount.crm_type || 'ghl',
            status: 'pushed',
            pushed_at: new Date(),
          });

          pushed++;
        } catch (err) {
          logger.error(`Failed to sync draft ${draft.id}: ${err.message}`);
          await db('sync_items').insert({
            batch_id: batch.id,
            account_id: subAccount.account_id,
            entity_type: 'draft',
            local_id: draft.id,
            crm_type: subAccount.crm_type || 'ghl',
            status: 'failed',
            error_message: err.message,
          });
          failed++;
        }
      }

      await db('sync_batches').where({ id: batch.id }).update({
        status: failed > 0 && pushed === 0 ? 'failed' : failed > 0 ? 'partial' : 'complete',
        pushed_count: pushed,
        failed_count: failed,
        completed_at: new Date(),
      });

      logger.info(`Sub-account ${subAccount.id}: pushed ${pushed}, failed ${failed}`);
      return { pushed, failed };

    } catch (err) {
      await db('sync_batches').where({ id: batch.id }).update({
        status: 'failed',
        error_log: JSON.stringify([err.message]),
        completed_at: new Date(),
      });
      throw err;
    }
  }

  async _getExistingCRMContactId(subAccount, localContactId) {
    const existing = await db('crm_contacts_map')
      .where({
        account_id: subAccount.account_id,
        local_contact_id: localContactId,
        crm_type: subAccount.crm_type || 'ghl',
      })
      .first();
    return existing?.crm_contact_id || null;
  }
}

export const batchSyncProcessor = new BatchSyncProcessor();
export default batchSyncProcessor;
