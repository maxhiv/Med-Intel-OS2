/**
 * Enrichment Queue Worker
 * Processes the contact_enrichment_queue table in priority order.
 * Called by scheduler every 30 minutes.
 */
import db from '../config/database.js';
import { enrichmentOrchestrator } from '../services/enrichment/EnrichmentOrchestrator.js';
import { logger } from '../config/logger.js';

export async function processEnrichmentQueue(batchSize = 25) {
  const items = await db('contact_enrichment_queue')
    .where({ status: 'queued' })
    .where('scheduled_at', '<=', new Date())
    .orderBy('priority', 'desc')
    .orderBy('scheduled_at', 'asc')
    .limit(batchSize)
    .select('*');

  if (!items.length) return { processed: 0, failed: 0 };

  logger.info(`Enrichment worker: processing ${items.length} contacts`);
  let processed = 0;
  let failed = 0;

  for (const item of items) {
    await db('contact_enrichment_queue').where({ id: item.id }).update({ status: 'running', started_at: new Date() });

    try {
      await enrichmentOrchestrator.enrichContact(item.contact_id);
      await db('contact_enrichment_queue').where({ id: item.id }).update({
        status: 'complete',
        completed_at: new Date(),
      });
      processed++;
    } catch (err) {
      logger.error(`Enrichment failed for contact ${item.contact_id}: ${err.message}`);
      await db('contact_enrichment_queue').where({ id: item.id }).update({
        status: 'failed',
        completed_at: new Date(),
        error_message: err.message,
      });
      failed++;
    }
  }

  logger.info(`Enrichment worker complete: ${processed} processed, ${failed} failed`);
  return { processed, failed };
}
