/**
 * Admin Controller
 * Platform admin (L0 Hansen Holdings) operations.
 * Includes enrichment source approval management.
 */
import db from '../config/database.js';
import bcrypt from 'bcryptjs';
import { AppError } from '../middleware/errorHandler.js';
import { enrichmentOrchestrator } from '../services/enrichment/EnrichmentOrchestrator.js';

// ── Accounts ─────────────────────────────────────────────────────────────────
export async function listAccounts(req, res) {
  const accounts = await db('accounts')
    .leftJoin(db('sub_accounts').count('* as sub_count').groupBy('account_id').as('sc'), 'sc.account_id', 'accounts.id')
    .select('accounts.*', db.raw('COALESCE(sc.sub_count, 0) as sub_account_count'))
    .orderBy('accounts.created_at', 'desc');
  res.json({ success: true, data: accounts });
}

export async function createAccount(req, res) {
  const { name, planTier = 'starter', defaultCrm = 'ghl', adminEmail, adminPassword } = req.body;

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const [account] = await db('accounts').insert({ name, slug, plan_tier: planTier, default_crm: defaultCrm }).returning('*');

  if (adminEmail && adminPassword) {
    const hash = await bcrypt.hash(adminPassword, 12);
    await db('users').insert({
      account_id: account.id,
      email: adminEmail,
      password_hash: hash,
      role: 'account_admin',
    });
  }

  res.status(201).json({ success: true, data: account });
}

export async function updateAccount(req, res) {
  const [updated] = await db('accounts').where({ id: req.params.id }).update(req.body).returning('*');
  if (!updated) throw new AppError('Account not found', 404);
  res.json({ success: true, data: updated });
}

export async function suspendAccount(req, res) {
  await db('accounts').where({ id: req.params.id }).update({ status: 'suspended' });
  res.json({ success: true, message: 'Account suspended' });
}

// ── Users ─────────────────────────────────────────────────────────────────────
export async function listUsers(req, res) {
  const users = await db('users').select('id', 'email', 'first_name', 'last_name', 'role', 'account_id', 'is_active', 'last_login_at');
  res.json({ success: true, data: users });
}

export async function createUser(req, res) {
  const { email, password, firstName, lastName, role, accountId } = req.body;
  const hash = await bcrypt.hash(password, 12);
  const [user] = await db('users').insert({
    email, password_hash: hash, first_name: firstName, last_name: lastName, role,
    account_id: accountId || null,
  }).returning('id', 'email', 'role');
  res.status(201).json({ success: true, data: user });
}

// ── Enrichment Source Approvals ────────────────────────────────────────────────
export async function listEnrichmentApprovals(req, res) {
  const approvals = await db('enrichment_source_approvals').select('*').orderBy('source');

  // Annotate with env status
  const withEnvStatus = approvals.map(a => ({
    ...a,
    env_key_present: Boolean(process.env[`${a.source.toUpperCase()}_API_KEY`] || 
                             process.env[`${a.source.toUpperCase()}_ACCESS_TOKEN`]),
    env_enabled: process.env[`${a.source.toUpperCase()}_ENABLED`] === 'true',
    is_free_source: ['npi_registry', 'doximity', 'website_scrape', 'cms_billing', 'professional_directory'].includes(a.source),
  }));

  res.json({ success: true, data: withEnvStatus });
}

export async function approveEnrichmentSource(req, res) {
  const { source } = req.params;
  const { notes, monthlyBudgetLimit } = req.body;

  const [updated] = await db('enrichment_source_approvals')
    .where({ source })
    .update({
      approved: true,
      approved_by: req.user.id,
      approved_at: new Date(),
      notes: notes || null,
      monthly_budget_limit: monthlyBudgetLimit || null,
      updated_at: new Date(),
    })
    .returning('*');

  if (!updated) throw new AppError(`Source '${source}' not found`, 404);

  // Invalidate the orchestrator approval cache
  enrichmentOrchestrator._approvalCache = null;
  enrichmentOrchestrator._cacheExpiry = 0;

  res.json({
    success: true,
    data: updated,
    message: `✅ ${source} approved. Enrichment pipeline can now use this source when env var is also enabled.`,
  });
}

export async function revokeEnrichmentSource(req, res) {
  const { source } = req.params;

  await db('enrichment_source_approvals').where({ source }).update({
    approved: false,
    approved_by: req.user.id,
    approved_at: null,
    updated_at: new Date(),
  });

  enrichmentOrchestrator._approvalCache = null;
  enrichmentOrchestrator._cacheExpiry = 0;

  res.json({ success: true, message: `${source} revoked — will not be used in enrichment` });
}

export async function setEnrichmentBudget(req, res) {
  const { source } = req.params;
  const { monthlyBudgetLimit } = req.body;

  await db('enrichment_source_approvals').where({ source }).update({
    monthly_budget_limit: monthlyBudgetLimit,
    updated_at: new Date(),
  });

  res.json({ success: true, message: `Budget updated for ${source}: $${(monthlyBudgetLimit / 100).toFixed(2)}/mo` });
}

// ── Platform Stats ─────────────────────────────────────────────────────────────
export async function platformStats(req, res) {
  const [stats] = await db.raw(`
    SELECT
      (SELECT COUNT(*) FROM facilities) as total_facilities,
      (SELECT COUNT(*) FROM facility_contacts) as total_contacts,
      (SELECT COUNT(*) FROM facility_contacts WHERE confidence_score >= 70) as verified_contacts,
      (SELECT COUNT(*) FROM accounts WHERE status = 'active') as active_accounts,
      (SELECT COUNT(*) FROM outreach_drafts WHERE status = 'pending') as pending_drafts,
      (SELECT COUNT(*) FROM purchase_signals WHERE is_active = true) as active_signals,
      (SELECT COUNT(*) FROM sync_batches WHERE batch_date = CURRENT_DATE) as batches_today
  `);
  res.json({ success: true, data: stats.rows[0] });
}

export async function ingestionStatus(req, res) {
  const recentIngestion = await db('financial_documents')
    .select(db.raw("doc_type, COUNT(*) as count, MAX(ingested_at) as last_ingested"))
    .groupBy('doc_type')
    .orderBy('last_ingested', 'desc');
  res.json({ success: true, data: recentIngestion });
}
