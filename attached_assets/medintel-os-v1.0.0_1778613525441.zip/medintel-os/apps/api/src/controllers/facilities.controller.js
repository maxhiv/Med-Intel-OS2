import db from '../config/database.js';
import { withRLS } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import { NPPESIngestionService } from '../services/ingestion/NPPESIngestionService.js';

export async function list(req, res) {
  const { state, type, minScore, search, limit = 50, offset = 0 } = req.query;

  let query = db('facilities')
    .leftJoin('facility_procurement', 'facility_procurement.facility_id', 'facilities.id')
    .leftJoin('facility_tech_stack', 'facility_tech_stack.facility_id', 'facilities.id')
    .select(
      'facilities.id', 'facilities.npi', 'facilities.name', 'facilities.facility_type',
      'facilities.city', 'facilities.state', 'facilities.beds', 'facilities.ownership',
      'facilities.signal_score', 'facilities.last_enriched_at',
      'facilities.cah_designation', 'facilities.teaching_hospital',
      'facility_tech_stack.ehr_vendor', 'facility_tech_stack.himss_emram_score',
      'facility_procurement.gpo_name', 'facility_procurement.fiscal_year_end',
      db.raw('(SELECT COUNT(*) FROM facility_contacts fc WHERE fc.facility_id = facilities.id) as contact_count'),
      db.raw('(SELECT COUNT(*) FROM purchase_signals ps WHERE ps.facility_id = facilities.id AND ps.is_active = true) as signal_count'),
    )
    .orderBy('facilities.signal_score', 'desc')
    .limit(Math.min(parseInt(limit), 200))
    .offset(parseInt(offset));

  if (state) query = query.where('facilities.state', state);
  if (type) query = query.where('facilities.facility_type', type);
  if (minScore) query = query.where('facilities.signal_score', '>=', parseInt(minScore));
  if (search) query = query.whereRaw('facilities.name ILIKE ?', [`%${search}%`]);

  const [facilities, [{ total }]] = await Promise.all([
    query,
    db('facilities').count('* as total').modify(q => {
      if (state) q.where('state', state);
      if (type) q.where('facility_type', type);
      if (minScore) q.where('signal_score', '>=', parseInt(minScore));
      if (search) q.whereRaw('name ILIKE ?', [`%${search}%`]);
    }),
  ]);

  res.json({ success: true, data: facilities, meta: { total: parseInt(total), limit, offset } });
}

export async function getById(req, res) {
  const facility = await db('facilities').where({ id: req.params.id }).first();
  if (!facility) throw new AppError('Facility not found', 404);

  const [signals, equipment, contacts, financials, accreditation, techStack, procurement, research, construction] = await Promise.all([
    db('purchase_signals').where({ facility_id: facility.id, is_active: true }).orderBy('confidence', 'desc').limit(20),
    db('equipment_records').where({ facility_id: facility.id }).orderBy('pct_depreciated', 'desc'),
    db('facility_contacts').where({ facility_id: facility.id }).orderBy('confidence_score', 'desc').limit(50),
    db('financial_documents').where({ facility_id: facility.id }).orderBy('fiscal_year', 'desc').limit(5),
    db('facility_accreditation').where({ facility_id: facility.id }).first(),
    db('facility_tech_stack').where({ facility_id: facility.id }).first(),
    db('facility_procurement').where({ facility_id: facility.id }).first(),
    db('facility_research').where({ facility_id: facility.id }).first(),
    db('facility_construction').where({ facility_id: facility.id }).first(),
  ]);

  res.json({ success: true, data: { ...facility, signals, equipment, contacts, financials, accreditation, techStack, procurement, research, construction } });
}

export async function create(req, res) {
  // Create via NPI lookup
  const { npi } = req.body;
  if (!npi) throw new AppError('NPI required', 400);

  const existing = await db('facilities').where({ npi }).first();
  if (existing) throw new AppError('Facility already exists', 409);

  const svc = new NPPESIngestionService();
  const data = await svc.syncFacilityByNPI(npi);
  if (!data) throw new AppError('NPI not found in NPPES registry', 404);

  const facility = await db('facilities').where({ npi }).first();
  res.status(201).json({ success: true, data: facility });
}

export async function update(req, res) {
  const [updated] = await db('facilities').where({ id: req.params.id }).update({ ...req.body, updated_at: new Date() }).returning('*');
  if (!updated) throw new AppError('Facility not found', 404);
  res.json({ success: true, data: updated });
}

export async function remove(req, res) {
  await db('facilities').where({ id: req.params.id }).del();
  res.json({ success: true });
}

export async function syncFromNPI(req, res) {
  const { npi } = req.params;
  const svc = new NPPESIngestionService();
  const data = await svc.syncFacilityByNPI(npi);
  if (!data) throw new AppError('NPI not found', 404);
  res.json({ success: true, data });
}

export async function getSignals(req, res) {
  const signals = await db('purchase_signals')
    .where({ facility_id: req.params.id, is_active: true })
    .orderBy('confidence', 'desc');
  res.json({ success: true, data: signals });
}
