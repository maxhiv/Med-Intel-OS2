import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../config/database.js';
import { config } from '../config/env.js';
import { AppError } from '../middleware/errorHandler.js';

function signToken(userId, role, accountId) {
  return jwt.sign({ sub: userId, role, accountId }, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES_IN,
  });
}

export async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) throw new AppError('Email and password required', 400);

  const user = await db('users').where({ email: email.toLowerCase(), is_active: true }).first();
  if (!user) throw new AppError('Invalid credentials', 401);

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) throw new AppError('Invalid credentials', 401);

  await db('users').where({ id: user.id }).update({ last_login_at: new Date() });

  const token = signToken(user.id, user.role, user.account_id);

  res.json({
    success: true,
    data: {
      token,
      user: { id: user.id, email: user.email, firstName: user.first_name, lastName: user.last_name, role: user.role, accountId: user.account_id },
    },
  });
}

export async function me(req, res) {
  const user = await db('users').where({ id: req.user.id }).first();
  const account = user.account_id ? await db('accounts').where({ id: user.account_id }).first() : null;
  res.json({ success: true, data: { ...user, password_hash: undefined, account } });
}

export async function refresh(req, res) {
  const { token } = req.body;
  if (!token) throw new AppError('Token required', 400);
  const decoded = jwt.verify(token, config.JWT_SECRET);
  const newToken = signToken(decoded.sub, decoded.role, decoded.accountId);
  res.json({ success: true, data: { token: newToken } });
}

export async function logout(req, res) {
  // Stateless JWT — client discards token. In production add token blacklist via Redis.
  res.json({ success: true, message: 'Logged out' });
}

export async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  const user = await db('users').where({ id: req.user.id }).first();
  const valid = await bcrypt.compare(currentPassword, user.password_hash);
  if (!valid) throw new AppError('Current password incorrect', 400);
  const hash = await bcrypt.hash(newPassword, 12);
  await db('users').where({ id: req.user.id }).update({ password_hash: hash });
  res.json({ success: true, message: 'Password updated' });
}
