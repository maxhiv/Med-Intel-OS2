import db from '../config/database.js';
import { AppError } from '../middleware/errorHandler.js';
import { enrichmentOrchestrator } from '../services/enrichment/EnrichmentOrchestrator.js';

export async function list(req, res) {
  const queue = await db('contact_enrichment_queue')
    .join('facility_contacts', 'facility_contacts.id', 'contact_enrichment_queue.contact_id')
    .join('facilities', 'facilities.id', 'facility_contacts.facility_id')
    .select(
      'contact_enrichment_queue.*',
      'facility_contacts.full_name', 'facility_contacts.confidence_score',
      'facilities.name as facility_name'
    )
    .where('contact_enrichment_queue.status', 'queued')
    .orderBy('contact_enrichment_queue.priority', 'desc')
    .limit(100);
  res.json({ success: true, data: queue });
}

export async function getById(req, res) {
  const item = await db('contact_enrichment_queue').where({ id: req.params.id }).first();
  if (!item) throw new AppError('Queue item not found', 404);
  res.json({ success: true, data: item });
}

export async function create(req, res) {
  const { contactId, priority = 5 } = req.body;
  const [item] = await db('contact_enrichment_queue')
    .insert({ contact_id: contactId, priority, trigger_reason: 'manual' })
    .onConflict('contact_id').merge({ priority, scheduled_at: new Date() })
    .returning('*');
  res.status(201).json({ success: true, data: item });
}

export async function update(req, res) {
  res.json({ success: true });
}

export async function remove(req, res) {
  await db('contact_enrichment_queue').where({ id: req.params.id }).del();
  res.json({ success: true });
}

export async function approvalStatus(req, res) {
  const approvals = await db('enrichment_source_approvals').select('*').orderBy('source');
  res.json({ success: true, data: approvals });
}
