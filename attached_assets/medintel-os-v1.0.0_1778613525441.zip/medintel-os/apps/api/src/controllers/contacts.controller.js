import db from '../config/database.js';
import { withRLS } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import { enrichmentOrchestrator } from '../services/enrichment/EnrichmentOrchestrator.js';

export async function list(req, res) {
  const { facilityId, minScore, status, search, limit = 50, offset = 0 } = req.query;

  let query = db('facility_contacts')
    .join('facilities', 'facilities.id', 'facility_contacts.facility_id')
    .select(
      'facility_contacts.*',
      'facilities.name as facility_name', 'facilities.city', 'facilities.state',
      'facilities.signal_score as facility_signal_score'
    )
    .orderBy('facility_contacts.confidence_score', 'desc')
    .limit(Math.min(parseInt(limit), 200))
    .offset(parseInt(offset));

  if (facilityId) query = query.where('facility_contacts.facility_id', facilityId);
  if (minScore) query = query.where('facility_contacts.confidence_score', '>=', parseInt(minScore));
  if (status) query = query.where('facility_contacts.email_status', status);
  if (search) query = query.whereRaw('facility_contacts.full_name ILIKE ?', [`%${search}%`]);

  const contacts = await query;
  res.json({ success: true, data: contacts });
}

export async function getById(req, res) {
  const contact = await db('facility_contacts')
    .join('facilities', 'facilities.id', 'facility_contacts.facility_id')
    .where('facility_contacts.id', req.params.id)
    .select('facility_contacts.*', 'facilities.name as facility_name')
    .first();
  if (!contact) throw new AppError('Contact not found', 404);

  const validationLog = await db('contact_validation_log')
    .where({ contact_id: contact.id })
    .orderBy('checked_at', 'desc')
    .limit(20);

  res.json({ success: true, data: { ...contact, validationLog } });
}

export async function create(req, res) {
  const [contact] = await db('facility_contacts').insert(req.body).returning('*');
  // Auto-queue for free enrichment
  await db('contact_enrichment_queue').insert({
    contact_id: contact.id,
    priority: 5,
    trigger_reason: 'manual_create',
  }).onConflict('contact_id').ignore();
  res.status(201).json({ success: true, data: contact });
}

export async function update(req, res) {
  const [updated] = await db('facility_contacts')
    .where({ id: req.params.id })
    .update({ ...req.body, updated_at: new Date() })
    .returning('*');
  if (!updated) throw new AppError('Contact not found', 404);
  res.json({ success: true, data: updated });
}

export async function remove(req, res) {
  await db('facility_contacts').where({ id: req.params.id }).del();
  res.json({ success: true });
}

export async function triggerEnrichment(req, res) {
  const { id } = req.params;
  const { dryRun = false } = req.query;

  // Only platform_admin or account_admin can trigger enrichment
  if (!['platform_admin', 'account_admin'].includes(req.user.role)) {
    throw new AppError('Insufficient permissions', 403);
  }

  const result = await enrichmentOrchestrator.enrichContact(id, { dryRun: dryRun === 'true' });
  res.json({ success: true, data: result });
}

export async function getEnrichmentStatus(req, res) {
  const queue = await db('contact_enrichment_queue')
    .where({ contact_id: req.params.id })
    .orderBy('scheduled_at', 'desc')
    .first();

  const approvals = await db('enrichment_source_approvals').select('source', 'approved');
  res.json({ success: true, data: { queue, approvals } });
}
