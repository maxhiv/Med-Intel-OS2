/**
 * Knex database configuration with connection pooling.
 * All tenant queries automatically get RLS applied via
 * the setTenantContext helper (sets app.account_id session var).
 */
import knex from 'knex';
import { config } from './env.js';
import { logger } from './logger.js';

export const db = knex({
  client: 'pg',
  connection: {
    connectionString: config.DATABASE_URL,
    ssl: config.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  },
  pool: {
    min: config.DATABASE_POOL_MIN,
    max: config.DATABASE_POOL_MAX,
    afterCreate: (conn, done) => {
      // Install pgvector extension on new connections
      conn.query('CREATE EXTENSION IF NOT EXISTS vector;', (err) => {
        if (err) logger.warn('pgvector extension:', err.message);
        done(err, conn);
      });
    },
  },
  migrations: {
    directory: '../../../database/migrations',
    tableName: 'knex_migrations',
    extension: 'sql',
  },
  debug: config.NODE_ENV === 'development' && config.LOG_LEVEL === 'debug',
  log: {
    warn: (msg) => logger.warn(msg),
    error: (msg) => logger.error(msg),
    deprecate: (msg) => logger.warn(msg),
    debug: (msg) => logger.debug(msg),
  },
});

/**
 * Set PostgreSQL RLS session variable for the current request.
 * Must be called before any tenant-scoped query.
 */
export async function withTenantContext(accountId, fn) {
  return db.transaction(async (trx) => {
    await trx.raw(`SET LOCAL app.account_id = ?`, [accountId]);
    return fn(trx);
  });
}

/**
 * Health check
 */
export async function checkDatabaseConnection() {
  try {
    await db.raw('SELECT 1');
    logger.info('✅ Database connected');
    return true;
  } catch (err) {
    logger.error('❌ Database connection failed:', err.message);
    return false;
  }
}

export default db;
