#!/usr/bin/env node
/**
 * Database seed — creates platform admin + system report templates
 */
import 'dotenv/config';
import pkg from 'pg';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
const { Client } = pkg;

const SYSTEM_TEMPLATES = [
  { name: 'Asset Inventory Report', category: 'assets', description: 'Full equipment inventory by facility with depreciation status' },
  { name: 'Depreciation Forecast', category: 'assets', description: '12-month equipment replacement forecast ranked by urgency' },
  { name: 'Financial Health Summary', category: 'financials', description: 'Revenue, margin, capex, and days cash on hand by facility' },
  { name: 'Purchase Signal Dashboard', category: 'signals', description: 'Active purchase signals ranked by score and type' },
  { name: 'Facility Comparison Matrix', category: 'intelligence', description: 'Side-by-side comparison across multiple facilities' },
  { name: 'Territory Overview', category: 'territory', description: 'All facilities + contacts in a sub-account territory' },
  { name: 'CON Activity Tracker', category: 'intelligence', description: 'Certificate of Need filings by state with status' },
  { name: 'Campaign Performance', category: 'outreach', description: 'Open rates, reply rates, pipeline created by campaign' },
];

async function seed() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  // Platform admin user
  const adminEmail = process.env.PLATFORM_ADMIN_EMAIL || 'max@hansenholdingsllc.com';
  const adminPw = process.env.PLATFORM_ADMIN_PW || 'ChangeMe123!';
  const hash = await bcrypt.hash(adminPw, 12);

  const { rows: existing } = await client.query('SELECT id FROM users WHERE email = $1', [adminEmail]);
  if (!existing.length) {
    await client.query(
      'INSERT INTO users (id, email, password_hash, first_name, last_name, role) VALUES ($1,$2,$3,$4,$5,$6)',
      [randomUUID(), adminEmail, hash, 'Max', 'Hansen', 'platform_admin']
    );
    console.log(`✅ Platform admin created: ${adminEmail}`);
    console.log(`⚠  Default password: ${adminPw} — CHANGE IMMEDIATELY`);
  } else {
    console.log(`⏭  Platform admin already exists: ${adminEmail}`);
  }

  // System report templates
  for (const tpl of SYSTEM_TEMPLATES) {
    await client.query(`
      INSERT INTO report_templates (id, name, description, category, data_sources, field_config, filter_config, is_system_template)
      VALUES ($1,$2,$3,$4,$5,$6,$7,true)
      ON CONFLICT DO NOTHING
    `, [randomUUID(), tpl.name, tpl.description, tpl.category, '{}', '[]', '[]']);
    console.log(`✅ System template: ${tpl.name}`);
  }

  await client.end();
  console.log('\n✅ Seed complete');
}

seed().catch(err => { console.error(err); process.exit(1); });
