/**
 * Centralized environment config with validation.
 * Fail fast on missing required vars.
 */
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(3001),
  
  // Auth
  JWT_SECRET: z.string().min(32, 'JWT_SECRET must be at least 32 chars'),
  JWT_EXPIRES_IN: z.string().default('8h'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),

  // Database
  DATABASE_URL: z.string().url(),
  DATABASE_POOL_MIN: z.coerce.number().default(2),
  DATABASE_POOL_MAX: z.coerce.number().default(20),

  // Redis
  REDIS_URL: z.string().default('redis://localhost:6379'),

  // AI
  ANTHROPIC_API_KEY: z.string().startsWith('sk-ant-'),
  ANTHROPIC_MODEL: z.string().default('claude-sonnet-4-20250514'),
  ANTHROPIC_MAX_TOKENS: z.coerce.number().default(4096),

  // GHL (existing platform — default enabled)
  GHL_API_KEY: z.string().optional(),
  GHL_LOCATION_ID: z.string().optional(),
  GHL_API_BASE: z.string().default('https://services.leadconnectorhq.com'),

  // Paid enrichment sources — all default false (approval required in UI)
  APOLLO_API_KEY: z.string().optional(),
  APOLLO_ENABLED: z.coerce.boolean().default(false),

  NETROWS_API_KEY: z.string().optional(),
  NETROWS_ENABLED: z.coerce.boolean().default(false),

  ZEROBOUNCE_API_KEY: z.string().optional(),
  ZEROBOUNCE_ENABLED: z.coerce.boolean().default(false),

  BOUNCER_API_KEY: z.string().optional(),
  BOUNCER_ENABLED: z.coerce.boolean().default(false),

  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  TWILIO_ENABLED: z.coerce.boolean().default(false),

  PDL_API_KEY: z.string().optional(),
  PDL_ENABLED: z.coerce.boolean().default(false),

  ZOOMINFO_USERNAME: z.string().optional(),
  ZOOMINFO_PASSWORD: z.string().optional(),
  ZOOMINFO_ENABLED: z.coerce.boolean().default(false),

  DEFINITIVE_HC_API_KEY: z.string().optional(),
  DEFINITIVE_HC_ENABLED: z.coerce.boolean().default(false),

  APIDECK_API_KEY: z.string().optional(),
  APIDECK_APP_ID: z.string().optional(),
  APIDECK_ENABLED: z.coerce.boolean().default(false),

  HUBSPOT_ACCESS_TOKEN: z.string().optional(),
  HUBSPOT_ENABLED: z.coerce.boolean().default(false),

  STORAGE_PROVIDER: z.enum(['local', 'gcs']).default('local'),
  GCS_BUCKET: z.string().optional(),

  LOG_LEVEL: z.enum(['error', 'warn', 'info', 'debug']).default('info'),
  PLATFORM_ADMIN_EMAIL: z.string().email().optional(),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌  Invalid environment variables:\n', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const config = parsed.data;
export default config;
