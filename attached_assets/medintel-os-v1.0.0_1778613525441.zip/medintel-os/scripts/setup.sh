#!/bin/bash
# MedIntel OS — First-time setup script
# Run from repo root: bash scripts/setup.sh

set -e
echo "🚀 MedIntel OS Setup"
echo "===================="

# Check Node
node_version=$(node -v 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$node_version" -lt 20 ]; then
  echo "❌ Node 20+ required (got $(node -v))"; exit 1
fi
echo "✅ Node $(node -v)"

# Install deps
echo ""
echo "📦 Installing dependencies..."
npm install

# Copy env if needed
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "✅ .env created from .env.example — FILL IN VALUES BEFORE RUNNING"
else
  echo "⏭  .env already exists"
fi

# Check Postgres
if command -v psql > /dev/null 2>&1; then
  echo "✅ PostgreSQL available"
else
  echo "⚠  PostgreSQL not found — install or use Replit's built-in DB"
fi

echo ""
echo "📋 NEXT STEPS:"
echo "  1. Fill in .env (DATABASE_URL, JWT_SECRET, ANTHROPIC_API_KEY)"
echo "  2. Run migrations:  npm run migrate"
echo "  3. Seed the DB:     npm run seed"
echo "  4. Start dev:       npm run dev"
echo ""
echo "  5. Login at http://localhost:5173"
echo "     Email:  max@hansenholdingsllc.com"
echo "     PW:     ChangeMe123!  ← CHANGE THIS"
echo ""
echo "  6. Approve enrichment sources: /admin/enrichment"
echo "     ⚠  IMPORTANT: No paid source runs until you approve it there."
